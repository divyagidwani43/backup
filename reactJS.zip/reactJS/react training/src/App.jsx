import React from 'react';
import Box_case from './Box';
export default function App() {
    return (
        <div>
            <Box_case />
        </div>
    )
}
