useEffect(() => {
    // ✅ Setup
    const timer = setInterval(() => {
        console.log("Running timer...");
    }, 1000);

    // ❌ Problem: Agar cleanup na karein, timer kabhi band nahi hoga

    // ✅ Cleanup return
    return () => {
        clearInterval(timer); // timer cleanup
        console.log("Component unmounted, timer cleared.");
    };
}, []); // empty dependency means run only on mount/unmount
