export default function ComponentsRe() {
    return (
        <div>
            <Card />
        </div>
    )

}

const Card = () => {
    return (
        <CardStyle>
            <h3>This is a reusable card</h3>
            <p>It can wrap any content.</p>
        </CardStyle>
    )
}
const CardStyle = ({ children }) => {
    const style = {
        padding: '20px',
        border: '1px solid gray',
        borderRadius: '10px',
        marginBottom: '20px',
        backgroundColor: '#f9f9f9'
    };
    return <div style={style}>{children}</div>;
};
