export default function ComponentCallback() {
    const [message, setMessage] = useState("No Message");

    const updateMessage = (newMessage) => {
        setMessage(newMessage);  // State change on child button click
    };

    return (
        <div>
            <h3>{message}</h3>
            <UpdateParentFromChild onUpdate={updateMessage} />
        </div>
    )
}

function UpdateParentFromChild({ onUpdate }) {
    return (
        <button onClick={() => onUpdate("Updated message from Child!")}>
            Update Message
        </button>
    );
}