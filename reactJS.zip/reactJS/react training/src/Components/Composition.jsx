// React mein tum multiple small components ko ek complex component 
// mein combine kar sakte ho. Isse code clean, reusable aur scalable banta hai.
export default function Profile() {
    return (
        <div style={profileStyle}>
            <Avatar />
            <Bio />
            <SocialLinks />
        </div>
    );
}

const profileStyle = {
    border: "1px solid gray",
    padding: "20px",
    borderRadius: "10px",
    maxWidth: "400px",
    margin: "auto",
    textAlign: "center"
};

const Avatar = () => {
    return (
        <img
            src="https://via.placeholder.com/100"
            alt="User Avatar"
            style={{ borderRadius: "50%" }}
        />
    );
};

const Bio = () => {
    return (
        <div>
            <h3>Aisha Khan</h3>
            <p>Frontend Developer from Delhi</p>
        </div>
    );
};

const SocialLinks = () => {
    return (
        <div>
            <a href="#">LinkedIn</a> | <a href="#">GitHub</a>
        </div>
    );
};
