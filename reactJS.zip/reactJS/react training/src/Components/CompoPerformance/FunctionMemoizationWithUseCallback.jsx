import React, { useState, useCallback } from "react";

const Child = React.memo(({ handleClick }) => {
    console.log("👶 Child rendered");
    return <button onClick={handleClick}>Click Child Button</button>;
});

// for any render or calling in parent function child 2 will be rendered as it doesnt have useCallback preventing the render
const Child2 = React.memo(({ handleClick }) => {
    console.log("👶 Child2 rendered");
    return <button onClick={handleClick}>Click Child2 Button</button>;
});

export default function UseCallbackFunc() {
    const [count, setCount] = useState(0);

    // useCallback prevents re-rendering of func when function is passed from parent to child
    // react memo prevents re-render of jsx components
    // Agar tum function ko child me props ke through bhej rahe ho, toh useCallback use karne se 
    // child unnecessary render nahi karega, jab tak dependency change na ho.
    // useCallback to avoid creating new function every render
    const handleClick = useCallback(() => {
        console.log("Child button clicked");
    }, []); // no dependency, so same function reference every time

    const handleClickNoCall = () => {
        console.log("Child2 button clicked");
        // for any render or calling in parent function child 2 will be rendered 
        // as it doesnt have useCallback preventing the render
    };

    return (
        <div>
            <h3>Count: {count}</h3>
            <button onClick={() => setCount(count + 1)}>Increment Count</button>
            <Child handleClick={handleClick} />
            <Child2 handleClick={handleClickNoCall} />
        </div>
    );
}
