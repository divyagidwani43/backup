import React from "react";
import { useState } from "react";
export default function CompoReactMemo() {
    const [count, setCount] = useState(0);
    return (
        <div>
            <MemoFunc name="Aisha" />
            {/* only called when page loads or something changes in this compo */}

            <NoMemoFunc name="No Memo" />
            {/* it will render everytime any function is called */}

            <p>{count}</p>
            <button onClick={() => setCount(count + 1)}>Increase</button>
        </div>
    );
}

const MemoFunc = React.memo(({ name }) => {
    console.log("MemoFunc rendered");
    return <p>Hello, {name}</p>;
});

const NoMemoFunc = (({ name }) => {
    console.log("No Memo Func rendered");
    return <p>Hello, {name}</p>;
});
