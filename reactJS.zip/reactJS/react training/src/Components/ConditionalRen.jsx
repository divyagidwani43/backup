export default function CompoCondiRen() {
    return (
        <div>
            <IfElseOp />
            <TernaryOp />
            <LogicalOp />
        </div>
    )
}
const IfElseOp = ({ isLoggedIn }) => {
    if (isLoggedIn) {
        return <p>Welcome back, user!</p>;
    } else {
        return <p>Please login.</p>;
    }
};

const TernaryOp = ({ name }) => {
    return (
        <p>{name ? `Hello, ${name}` : "Guest, please sign in"}</p>
    );
};

const LogicalOp = ({ itemCount }) => {
    return (
        <div>
            <h2>Your Cart</h2>
            {itemCount > 0 && <p>You have {itemCount} items</p>}
        </div>
    );
};
