// Basics of Props, props = "properties".  
// Ye object hai jo parent component child ko bhejta hai — jaise function ko argument pass karte h.
// `App` component `Profile` component ko call kar raha hai

import { useState } from "react";
import { useEffect } from "react";

const user = {
    name: "Aisha",
    age: 24,
    city: "Delhi",
};

export default function PropsApp() {
    const [Var, changeVarFunc] = useState(0);
    const showAlert = () => {
        alert("Child ne button dabaya!");
    }
    const [online, setOnline] = useState(true)

    const [count, setCount] = useState(0); //this will be updated from child
    const increase = () => setCount(count + 1);
    return (
        <div>
            <h3>PropsApp rendering</h3>
            {/* yha isne values bheji h wo object form m recieve hongi */}
            <Profile name="Anjali" age={24} />
            <ProfileDestr name="Anjali" age={24} />
            <ProfileDestrLater name="Anjali" age={24} />
            <ProfileDestrMissedValue name="Anjali" age={24} />

            <Profile_No_Pre_Defined name="Anjali" />
            <Pre_defined_inFunc age={17} />

            <PropsChild>
                <h3>whatever is here will be desplayed at props.children</h3>
            </PropsChild>

            <UsePropChild>
                <p>can be used as wrapper and its reusable</p>
            </UsePropChild>

            <SpreadObjSent {...user} />

            <CondiRender hasUnread={true} />
            <IfElseRender online={online} var={Var} setOnline={setOnline} />

            <UseStateUse funcSent={changeVarFunc} value={Var} />
            <PassFunction func={showAlert} />


            <div>
                <h2>Count: {count}</h2>
                <UpdateParentFromChild triggerUpdate={increase} />
            </div>

            <RestOP className={'none'} children={'hiii'} style={'style={{border:2px solid black}}'} />
        </div>
    )
}

const Profile = (props) => {
    // React is doing : props = { name: "Anjali", age: 24}
    // usse dot (`props.name`) ya destructuring (`{ name }`) to access
    // props.name = "Ravi";  // NOT allowed, Immutable, data change(`useState`)
    return <p>{props.name} is {props.age} years old</p>;
};


const ProfileDestr = ({ name, age: duration }) => {
    return (
        <div>{name + " " + duration}</div>
    )
}

const ProfileDestrLater = (props) => {
    const { name, age } = props;
    // destructure here
    return (
        <div>
            <span>{name} </span>
            <span>{age}</span>
        </div>
    )
}

// kuch props destructure karo, baaki ignore ho jaayein, koi dikkat nahi:
const ProfileDestrMissedValue = ({ name }) => {
    return <h2>{name}</h2>;
};
// error nahi aayega.


const Profile_No_Pre_Defined = ({ name, age }) => {
    return (
        <div>
            <p>{name + " " + age}</p>
            {/* age = undefined */}
        </div>
    )
}

// Default Props – tum ek default value set kar sakte ho if prop value nhi mile
const Pre_defined_inFunc = ({ name = "Guest", age = 18 }) => {
    // Agar name na bheja gaya toh yeh guest print karega
    return (
        <div>
            <p>{name + " " + age}</p>
        </div>
    )
}

const PropsChild = (props) => {
    return <div className="card">{props.children}</div>;
};

const UsePropChild = (props) => {
    const cardStyle = {
        border: '1px solid #ddd',
        borderRadius: '12px',
        padding: '20px',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.1)',
        backgroundColor: '#fff',
        margin: '20px auto',
        maxWidth: '400px',
        textAlign: 'center',
        fontFamily: 'Arial, sans-serif',
    };

    return <div style={cardStyle}>{props.children}</div>;
}

const SpreadObjSent = ({ name, age, city }) => {
    return <p>{name} is {age} years old from {city}.</p>;
}

const CondiRender = ({ hasUnread }) => {
    return (
        <div>
            <h2>Inbox</h2>
            {hasUnread && <p>You have unread messages!</p>}
            {/* can have any other conditional rendering ways too */}
            {hasUnread ? <p>You have unread messages!</p> : <p>all read</p>}
        </div>
    );
};

const IfElseRender = ({ online, var: Var, setOnline }) => {
    useEffect(() => {
        setOnline((prev) => !prev)
    }, Var)
    if (online) {
        return <p>User is online 🟢</p>;
    } else {
        return <p>User is offline 🔴</p>;
    }
};

const UseStateUse = ({ value, funcSent }) => {

    useEffect(() => {
        console.log("Count changed:", value);
    }, [value]);

    const callingFunc = () => {
        funcSent((prev) => prev + 1)
    }
    return (
        <div>
            <p>{value}</p>
            <button onClick={callingFunc}>click to change value</button>
        </div>

    )
}

const PassFunction = ({ func }) => {
    <button onClick={() => func()}>alert</button>
}

function UpdateParentFromChild({ triggerUpdate }) {
    return <button onClick={triggerUpdate}>Increase</button>;
}

const RestOP = ({ children, className, ...rest }) => {
    const defaultStyle = {
        border: '1px solid gray',
        padding: '20px',
        margin: '20px',
        borderRadius: '10px',
        backgroundColor: '#f9f9f9'
    };

    return (
        <div style={defaultStyle} className={className} {...rest}>
            {children}
        </div>
    );
};
