import { useState } from "react";

export default function ComponentEvent() {
    return (
        <div>
            <UsingUseState />
            <br />
            <UsingEventHandler />
        </div>
    )
}

function UsingUseState() {
    const [count, setCount] = useState(0);
    const handleClick = () => {
        setCount((count) => (count + 1));
    };
    return (
        <div>
            <p>Clicked: {count} times</p>
            <button onClick={handleClick}>Click Me</button>
        </div>
    );
}

function UsingEventHandler() {
    const [text, setText] = useState("");
    return (
        <div>
            <input
                type="text"
                value={text}
                onChange={(e) => setText(e.target.value)}
            />
            <p>Typed: {text}</p>
        </div>
    );
}
