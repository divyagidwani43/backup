// Functional Component — Basic Syntax:
// React mein har component Capital letter se start hona chahiye.
// React small letters ko HTML tags samajhta hai (jaise <div>, <span>, etc.) Isliye wo usePropChild ko valid component nahi samajh raha.
// Ye ek JavaScript function hai jo JSX return karta hai.
function MyComponent() {
    return (
        <div>
            <p>Hello from Functional Component</p>
        </div>
    );
}

// Ya arrow function se bhi bana sakte ho:
const MyComponentArrow = () => {
    return <p>Arrow Function Style</p>;
};

//  Props in Functional Components
function Greet(props) {
    return <p>Hello, {props.name}</p>;
}

//  Use in App:
export default function ComponentsApp() {
    return (
        <div>
            <h1>Rendering ComponentsApp</h1>
            <MyComponent />
            <Greet name="Amit" />
        </div>
    );
}

//  Feature                 | Description
//  Simple Function         | JS function hota hai
//  JSX return karta hai    | HTML-like code
//  Props use kar sakta hai | Parent se data le sakta hai
//  Hooks support karta hai | useState, useEffect etc. 