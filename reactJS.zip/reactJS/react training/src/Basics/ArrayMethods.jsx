import React from "react";

// 1. map()
// Expected Output: 
// Ankit
// Priya
// Ravi
export function MapExample() {
    const names = ['Ankit', 'Priya', 'Ravi'];
    return (
        <div>
            <h4>Map Example</h4>
            <ul>
                {names.map(name => <li key={name}>{name}</li>)}
            </ul>
        </div>
    );
}

// 2. filter()
// Expected Output: 
// Riya
export function FilterExample() {
    const users = [
        { name: 'Riya', online: true },
        { name: 'Kabir', online: false },
    ];
    return (
        <div>
            <h4>Filter Example</h4>
            <ul>
                {users
                    .filter(user => user.online)
                    .map(user => <li key={user.name}>{user.name}</li>)}
            </ul>
        </div>
    );
}

// 3. slice()
// Expected Output: 
// A B
export function SliceExample() {
    const items = ['A', 'B', 'C', 'D'];
    return (
        <div>
            <h4>Slice Example</h4>
            <div>
                {items.slice(0, 2).map(item => <span key={item}>{item} </span>)}
            </div>
        </div>
    );
}

// 4. find()
// Expected Output: 
// Found: Phone
export function FindExample() {
    const products = [
        { id: 1, name: 'Laptop' },
        { id: 2, name: 'Phone' },
    ];
    const product = products.find(p => p.id === 2);
    return (
        <div>
            <h4>Find Example</h4>
            <p>Found: {product.name}</p>
        </div>
    );
}

// 5. reduce()
// Expected Output:
// Total: ₹300
export function ReduceExample() {
    const cart = [
        { item: 'A', price: 100 },
        { item: 'B', price: 200 },
    ];
    const total = cart.reduce((sum, curr) => sum + curr.price, 0);
    return (
        <div>
            <h4>Reduce Example</h4>
            <p>Total: ₹{total}</p>
        </div>
    );
}

// 6. some() / every()
// Expected Output: 
// Pending tasks left.
export function SomeEveryExample() {
    const tasks = [
        { task: 'Code', done: true },
        { task: 'Sleep', done: false },
    ];
    const allDone = tasks.every(t => t.done);
    return (
        <div>
            <h4>Every/Some Example</h4>
            <p>{allDone ? 'All tasks done!' : 'Pending tasks left.'}</p>
        </div>
    );
}

// 7. sort()
// Expected Output: 
// 90
// 75
// 60
// 45
export function SortExample() {
    const scores = [75, 90, 45, 60];
    return (
        <div>
            <h4>Sort Example</h4>
            {scores.sort((a, b) => b - a).map(score => <p key={score}>{score}</p>)}
        </div>
    );
}

// 8. reverse()
// Expected Output:
// Bye
// How are you?
// Hi
export function ReverseExample() {
    const messages = ['Hi', 'How are you?', 'Bye'];
    return (
        <div>
            <h4>Reverse Example</h4>
            {messages.slice().reverse().map(msg => <p key={msg}>{msg}</p>)}
        </div>
    );
}

// Optional: Main wrapper to show all together
export default function ArrayMethodsDemo() {
    return (
        <div>
            <h2>All Array Methods in JSX</h2>
            <MapExample />
            <FilterExample />
            <SliceExample />
            <FindExample />
            <ReduceExample />
            <SomeEveryExample />
            <SortExample />
            <ReverseExample />
        </div>
    );
}
