// 1. if-else statement (outside JSx)
function Message({ isLoggedIn }) {
    if (isLoggedIn) {
        return <p>Welcome Back!</p>;
    } else {
        return <p>Please Login</p>;
    }
}
// Yeh approach best hai jab tum pura different  return karna chahte ho.


// 2. Ternary Operator (inside JSX)
function Message({ isLoggedIn }) {
    return (
        <div>
            {isLoggedIn ? <p>Welcome Back!</p> : <p>Please Login</p>}
        </div>
    );
}
//  Best for simple one-liners.

// 3. Logical AND (`&&`) operator
function Notification({ hasUnread }) {
    return (
        <div>
            <h2>Inbox</h2>
            {hasUnread && <p>You have unread messages!</p>}
        </div>
    );
}

// 4. Conditional variable with JS
function Message({ isLoggedIn }) {
    let message;
    if (isLoggedIn) {
        message = <p>Welcome Back!</p>;
    } else {
        message = <p>Please Login</p>;
    }
    return <div>{message}</div>;
}