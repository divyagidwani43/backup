import React from "react";

// 👇 Dummy object with nested values
const user = {
    name: "Anjali",
    address: {
        city: "Delhi",
    },
};

const userWithoutAddress = {
    name: "Ravi",
    // address missing
};

// Optional Chaining (?.)
// 🔸 Safe access to deeply nested properties
export function OptionalChainingDemo() {
    return (
        <div>
            {/* Output: Delhi */}
            <p>City: {user.address?.city}</p>

            {/* Output: undefined (no error, safe access) */}
            <p>City: {userWithoutAddress.address?.city}</p>

            {/* Output: Not Available (using fallback with ||) */}
            <p>City: {userWithoutAddress.address?.city || "Not Available"}</p>
        </div>
    );
}

// Nullish Coalescing (??)
// 🔸 Fallback only if value is null or undefined (not for '', 0, false)
export function NullishCoalescingDemo() {
    const age1 = 0;            // falsy
    const age2 = null;         // null
    const age3 = undefined;    // undefined

    return (
        <div>
            {/* Output: Age: 0 (because 0 is NOT null/undefined) */}
            <p>Age: {age1 ?? "Not Provided"}</p>

            {/* Output: Age: Not Provided (null triggers fallback) */}
            <p>Age: {age2 ?? "Not Provided"}</p>

            {/* Output: Age: Not Provided (undefined triggers fallback) */}
            <p>Age: {age3 ?? "Not Provided"}</p>
        </div>
    );
}

export default function OptionalNullishDemo() {
    return (
        <div>
            <h2>Optional Chaining & Nullish Coalescing</h2>
            <OptionalChainingDemo />
            <NullishCoalescingDemo />
        </div>
    );
}
