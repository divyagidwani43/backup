// ✅ JavaScript in React – Quick Cheat Sheet

// -------------------------------
// 1. Variable & Function
const name = "React";
const greet = () => `Hello, ${name}`;

// -------------------------------
// 2. Destructuring
const user = { name: "Aisha", age: 24 };
const { name: userName, age } = user;

// -------------------------------
// 3. Spread & Rest
const newUser = { ...user, city: "Delhi" };
const printName = ({ name, ...rest }) => console.log(name);

// -------------------------------
// 4. Array Methods (React rendering)
const users = ["Ali", "Zara", "Imran"];
const userList = users.map((u, i) => <li key={i}>{u}</li>);

// -------------------------------
// 5. Conditional Rendering
const isLoggedIn = true;
return (
    <div>
        {isLoggedIn ? <p>Welcome!</p> : <p>Please log in.</p>}
        {isLoggedIn && <button>Logout</button>}
    </div>
);

// -------------------------------
// 6. Template Literals
const city = "Mumbai";
const msg = `Welcome to ${city}`;

// -------------------------------
// 7. Optional Chaining & Nullish Coalescing
const userCity = user?.address?.city ?? "Unknown";

// -------------------------------
// 8. Arrays & Object Manipulations
const newArr = [...users, "Sara"];
const updatedUser = { ...user, age: 25 };

// -------------------------------
// 9. Closures & Callbacks
const handleClick = () => {
    setTimeout(() => {
        console.log("Clicked!");
    }, 1000);
};

// -------------------------------
// 10. Async/Await + useEffect
useEffect(() => {
    const fetchData = async () => {
        const res = await fetch("/api/data");
        const data = await res.json();
        console.log(data);
    };
    fetchData();
}, []);

// -------------------------------
// 11. Module Imports/Exports
// File: Hello.js
export default function Hello() { return <h1>Hello!</h1>; }
// File: App.js
import Hello from "./Hello";

// -------------------------------
// 12. Events Handling
function def() {
    return (
        <div>
            <input onChange={(e) => setValue(e.target.value)} />
            <button onClick={() => console.log("Clicked")}>Click Me</button>
        </div>
    )
}

// -------------------------------
// 13. useMemo & useCallback
const memoValue = useMemo(() => computeHeavyThing(data), [data]);
const memoFunc = useCallback(() => handleSomething(id), [id]);

// -------------------------------
// 14. JSON Helpers
console.log(JSON.stringify(user));
console.log(Object.keys(user));
