import React from "react";

// 1. toUpperCase()
// Output: HELLO WORLD
export function UpperCaseExample() {
    const text = "hello world";
    return <p>{text.toUpperCase()}</p>;
}

// 2. toLowerCase()
// Output: hello world
export function LowerCaseExample() {
    const text = "HELLO WORLD";
    return <p>{text.toLowerCase()}</p>;
}

// 3. trim()
// Output: Hello (whitespace removed)
export function TrimExample() {
    const name = "   Hello   ";
    return <p>{name.trim()}</p>;
}

// 4. slice()
// Output: lo
export function SliceExample() {
    const str = "Hello";
    return <p>{str.slice(3)}</p>;
}

// 5. substring()
// Output: ell
export function SubstringExample() {
    const str = "Hello";
    return <p>{str.substring(1, 4)}</p>;
}

// 6. includes()
// Output: Found!
export function IncludesExample() {
    const str = "React is awesome!";
    return <p>{str.includes("awesome") ? "Found!" : "Not found"}</p>;
}

// 7. replace()
// Output: JavaScript is awesome!
export function ReplaceExample() {
    const str = "React is awesome!";
    return <p>{str.replace("React", "JavaScript")}</p>;
}

// 8. split()
// Output: [A, B, C]
export function SplitExample() {
    const str = "A,B,C";
    const items = str.split(",");
    return (
        <ul>
            {items.map((item, index) => (
                <li key={index}>{item}</li>
            ))}
        </ul>
    );
}

// 9. concat()
// Output: Hello World
export function ConcatExample() {
    const a = "Hello";
    const b = "World";
    return <p>{a.concat(" ", b)}</p>;
}

// 10. startsWith() / endsWith()
// Output: Starts with Hello: true | Ends with World: true
export function StartEndExample() {
    const str = "Hello World";
    return (
        <p>
            Starts with Hello: {str.startsWith("Hello") ? "true" : "false"} | Ends with
            World: {str.endsWith("World") ? "true" : "false"}
        </p>
    );
}

// Main wrapper
export default function StringOperationsDemo() {
    return (
        <div>
            <h2>String Operations in JSX</h2>
            <UpperCaseExample />
            <LowerCaseExample />
            <TrimExample />
            <SliceExample />
            <SubstringExample />
            <IncludesExample />
            <ReplaceExample />
            <SplitExample />
            <ConcatExample />
            <StartEndExample />
        </div>
    );
}
