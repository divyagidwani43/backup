// React mein loops directly JSX ke andar for loop se nahi likhe jaate (kyunki JSX is like HTML inside 
// JavaScript), lekin hum .map() method ka use karke UI elements render karte hain.
export default function LoopsInReact() {
    return (
        <div>
            <p>loop ren</p>
            <LoopWork />
            <p>map ren</p>
            <FruitList />
        </div>
    )
}
// 1. List Rendering using .map()
const fruits = ['Apple', 'Banana', 'Orange'];
function FruitList() {
    return (
        <ul>
            {fruits.map((fruit, index) => (
                <li key={index}>{fruit}</li>
            ))}
        </ul>
    );
}
// ⚠️ key prop zaruri hoti hai, especially when rendering lists — React ko batata hai ki kaunsa element uniquely identify hota hai.
// function WontWork() {
//     // This won't work:
//     return (
//         <ul>
//             for(let i = 0; i < arr.length; i++) {
//                 <li>{arr[i]}</li>   // ❌ invalid
//             }
//         </ul>
//     );
// }
// Instead, pehle loop ke result ko variable me save karo:

function LoopWork() {
    const items = [];
    for (let i = 0; i < fruits.length; i++) {
        items.push(<li key={i}>{fruits[i]}</li>);
    }
    return <ul>{items}</ul>;
}