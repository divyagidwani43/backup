SELECT DB_NAME() AS CurrentDatabase;
-- Konsa databse h wo dikhaya

SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo';
-- kya h database mein wo sb

-- For students table
SELECT COLUMN_NAME, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'students' AND TABLE_SCHEMA = 'dbo';

-- Show columns of 'students' table
SELECT COLUMN_NAME, DATA_TYPE 
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'students';

-- Show all constraints
SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS;

-- Show which column has a primary/foreign key
SELECT * FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'students';


-- Task 1: List all tables present in the current database using INFORMATION_SCHEMA.
select * from INFORMATION_SCHEMA.TABLES;

-- Task 2: Find all columns from the 'students' table along with their data types.
SELECT COLUMN_NAME,DATA_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='students';

-- Task 3: Show all constraints applied on the 'faculty' table.
SELECT * FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS WHERE TABLE_NAME='faculty'