use sql_prep;
CREATE TABLE students (
    student_id INT PRIMARY KEY,
    name VARCHAR(50),
    age INT,
    subject_id INT
);

INSERT INTO students (student_id, name, age, subject_id) VALUES
(1, 'Aman', 20, 101),
(2, 'Riya', 21, 102),
(3, 'Sameer', 19, 103),
(4, 'Pooja', 22, 101),
(5, 'Kabir', 20, 102);

CREATE TABLE subjects (
    subject_id INT PRIMARY KEY,
    subject_name VARCHAR(50),
    faculty_id INT
);

INSERT INTO subjects (subject_id, subject_name, faculty_id) VALUES
(101, 'Mathematics', 1),
(102, 'Physics', 2),
(103, 'Chemistry', 3);

CREATE TABLE faculty (
    faculty_id INT PRIMARY KEY,
    faculty_name VARCHAR(50),
    department VARCHAR(50)
);

INSERT INTO faculty (faculty_id, faculty_name, department) VALUES
(1, 'Dr. Sharma', 'Mathematics'),
(2, 'Prof. Verma', 'Physics'),
(3, 'Dr. Mehta', 'Science');

-- Insert more faculty members
INSERT INTO faculty (faculty_id, faculty_name, department) VALUES
(4, 'Prof. Iyer', 'Biology'),
(5, 'Dr. Khan', 'English'),
(6, 'Prof. Das', 'History'),
(7, 'Dr. Singh', 'Computer Science'),
(8, 'Prof. Nair', 'Economics'),
(9, 'Dr. Joshi', 'Philosophy'),
(10, 'Prof. Chauhan', 'Geography');

-- Insert more subjects (total 10 now)
INSERT INTO subjects (subject_id, subject_name, faculty_id) VALUES
(104, 'Biology', 4),
(105, 'English', 5),
(106, 'History', 6),
(107, 'Computer Science', 7),
(108, 'Economics', 8),
(109, 'Philosophy', 9),
(110, 'Geography', 10);

-- Insert more students (total 10 now)
INSERT INTO students (student_id, name, age, subject_id) VALUES
(6, 'Neha', 20, 104),
(7, 'Aarav', 21, 105),
(8, 'Tanya', 22, 106),
(9, 'Raj', 20, 107),
(10, 'Meena', 23, 108);

-- Insert 6 more students into the 'students' table
INSERT INTO students (student_id, name, age, subject_id) VALUES
(11, 'Anjali', 21, 109),   -- Philosophy
(12, 'Vikram', 22, 110),   -- Geography
(13, 'Sneha', 20, 104),    -- Biology
(14, 'Rohit', 19, 105),    -- English
(15, 'Divya', 22, 106),    -- History
(16, 'Yash', 21, 107);     -- Computer Science

