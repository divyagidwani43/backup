--CTE

--WITH cte_name AS (
    -- CTE ka logic yaha likhte hain
--    SELECT column1, column2
--    FROM table_name
--    WHERE condition
--)
-- Use CTE in main query
--SELECT *
--FROM cte_name;

WITH SubjectCount AS (
    SELECT subject_id, COUNT(*) AS no_of_students
    FROM students
    GROUP BY subject_id
)
select * from SubjectCount;
-- ab iss table ko kahi bhi use krlo ye ek digital table h yha

-- Task 1: Use a CTE to calculate the number of students per subject and show it with the subject name.
WITH students_per_sub AS(
	SELECT subject_id, count(*) as students
	from students
	group by subject_id
)
select students, sub.subject_name from students_per_sub 
join subjects sub on sub.subject_id = students_per_sub.subject_id;
-- Task 2: Create a CTE that finds the faculty who teach the most subjects.
-- Task 3: Use a CTE to show students who are enrolled in more than one subject, and their corresponding subjects.

