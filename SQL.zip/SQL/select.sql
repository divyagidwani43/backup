use sql_prep;

select * from faculty;
select * from students;
select * from subjects;

