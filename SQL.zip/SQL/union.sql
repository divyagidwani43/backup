-- union
SELECT name FROM students
UNION
SELECT faculty_name FROM faculty;

-- UNION ALL
-- Duplicates ko remove nahi karta.
-- Sabhi rows (including duplicates) ko return karta hai. Thoda fast hota hai, kyunki duplicate check nahi karna padta.

SELECT name FROM students
UNION ALL
SELECT faculty_name FROM faculty;