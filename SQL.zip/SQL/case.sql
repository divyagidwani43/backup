use sql_prep;
-- CASE
--SELECT 
--    column_name,
--    CASE 
--        WHEN condition1 THEN result1
--        WHEN condition2 THEN result2
--        ELSE default_result
--    END AS alias_name
--FROM table_name;

SELECT 
    name,
    age,
    CASE 
        WHEN age < 20 THEN 'Teenager'
        WHEN age BETWEEN 20 AND 21 THEN 'Young Adult'
        ELSE 'Adult'
    END AS age_category
FROM students;



-- Task 2: Show each subject name and label "Core" if subject is Mathematics or Physics, else "Elective".
select subject_name , 
	CASE
		WHEN subject_name='Physics' OR subject_name ='Mathematics' THEN 'Core'
		ELSE 'Elective'
	END AS labeling
FROM subjects;
