-- SUM(): Calculates the sum of values in a numeric column.
-- Example: SELECT SUM(price) FROM products;  -- Total price of all products.

-- AVG(): Calculates the average value of a numeric column.
-- Example: SELECT AVG(age) FROM students;  -- Average age of all students.

-- MIN(): Returns the minimum value in a column.
-- Example: SELECT MIN(salary) FROM employees;  -- Minimum salary among all employees.

-- MAX(): Returns the maximum value in a column.
-- Example: SELECT MAX(salary) FROM employees;  -- Maximum salary among all employees.

-- get students with age more than avg age 
-- select * from students where age > avg(age) -- WRONG 
-- The WHERE clause is evaluated before the aggregate function, and aggregate function require groupinG
select * from students where age > (select avg(age) from students);

-- Task 1: Show subject_id, number of students, and average age,
-- but only for subjects where average age > 21 and student count > 2.
SELECT subject_id, count(*), avg(age) from students group by subject_id having AVG(age)>21 AND count(*)>2;

-- Task 9: Display students whose age is **greater than both**
-- average age of their subject AND average age of all students.
select subject_id, avg(age) as avg_age_per_sub from students group by subject_id having avg(age) > (select avg(age) from students)

