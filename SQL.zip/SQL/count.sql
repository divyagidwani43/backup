-- COUNT
-- COUNT() ka use hum tab karte hain jab hume kisi specific column mein ya poori table mein kitni rows hain 
-- ya kisi condition ko satisfy karte hue kitni rows hain, yeh count karna ho.
-- COUNT(*): Ye poori table mein rows count karta hai, chahe column mein null values bhi ho.
-- COUNT(column_name): Yeh sirf wo rows count karega jisme specific column ka value non-null ho.
-- can only be used with -
-- GROUP BY Clause: Aggregate functions can be used with GROUP BY to group data and perform calculations
-- HAVING Clause: Use HAVING to filter results of aggregate functions 
-- ORDER BY: You can use aggregate functions with ORDER BY to sort grouped results 

SELECT COUNT(*) FROM students;
-- Isse tumhe students table mein total rows milenge, chahe kisi column mein null values hon ya na hon

SELECT COUNT(subject_id) FROM students;
-- Agar kisi student ka subject_id NULL hai, toh usse count nahi kiya jaayega.

SELECT COUNT(DISTINCT subject_id) FROM students;
-- jo subjects repeat ho rahe hain unko ek hi baar count kiya jayega

SELECT subject_id, COUNT(*) AS number_of_students
FROM students
GROUP BY subject_id;
-- Isse tumhe har subject ke liye students ka count milega.

