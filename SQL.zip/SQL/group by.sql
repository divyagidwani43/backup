-- GROUP BY ka kaam hota hai data ko group karna kisi column ke basis pe.
-- HAVING ka kaam hota hai grouped data pe filter lagana. (Jaise WHERE individual rows pe filter lagata hai, waise HAVING groups pe.)

-- Task 3: Show only those subjects where more than 1 student is enrolled.
SELECT 
    S.SUBJECT_ID, 
    COUNT(*) AS ENROLLMENTS, 
    SUB.SUBJECT_NAME
-- agr yha do elements selected h with count toh dono ko hi group by mein dalo nhi to group nhi hoga
FROM STUDENTS S
LEFT JOIN SUBJECTS SUB 
    ON SUB.SUBJECT_ID = S.SUBJECT_ID

GROUP BY S.SUBJECT_ID, SUB.SUBJECT_NAME
HAVING COUNT(*) > 1
ORDER BY COUNT(*) ASC;


select * from students;
select * from subjects;

-- Task 1: Har subject ke liye students ka average age nikaalo. (Use GROUP BY)
-- Task 2: Wo subjects dikhaiye jisme 3 se zyada students enrolled hain. (Use HAVING)
-- Task 3: Faculty ke hisaab se students ka count karo. (Join subjects and faculty tables, then GROUP BY faculty)
-- Task 4: Wo faculty dikhaiye jisme sabse kam students enrolled hain. (Use ORDER BY and GROUP BY)
-- Task 5: 'Mathematics' aur 'Physics' subjects mein total students ka count karo.

