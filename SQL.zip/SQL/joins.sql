﻿-- INNER JOIN
-- 👉 Sirf matching records dono tables se deta hai.

SELECT s.name, sub.subject_name
FROM students s
INNER JOIN subjects sub ON s.subject_id = sub.subject_id;

-- LEFT JOIN (LEFT OUTER JOIN)
--👉 Left table ke saare records aayenge. Agar match mil gaya right table mein, toh values fill hongi, warna NULL.

SELECT s.name, sub.subject_name
FROM students s
LEFT JOIN subjects sub ON s.subject_id = sub.subject_id;

-- FULL OUTER JOIN
--👉 Dono tables ke saare records aate hain. Jahan match nahi milta, NULL aa jata hai.

SELECT s.name, sub.subject_name
FROM students s
FULL OUTER JOIN subjects sub ON s.subject_id = sub.subject_id;
