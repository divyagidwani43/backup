from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Set up the WebDriver (Replace with the path to your WebDriver)
driver = webdriver.Edge()  # Or use webdriver.Firefox() for Firefox
driver.maximize_window() # used to maximize the browser window to full screen.
# driver.set_window_size(1920, 1080)  # Manually set the window size


# Open a webpage
driver.get("https://www.google.com")

# Open a new tab
driver.switch_to.new_window("tab")

# another webpage
driver.get("https://peopleplus.zoho.com/hrportal1524046337539/zp#home/myspace/overview-actionlist")

# Open a new tab
driver.switch_to.new_window("tab")

# another webpage
driver.get("https://www.youtube.com")

# Find the search bar
search_box = driver.find_element(By.NAME, "search_query")

# Type "Shinchan" and press Enter
search_box.send_keys("Shinchan")

time.sleep(1)  # Small delay before pressing enter
search_box.send_keys(Keys.RETURN) 
"""
Sends the "Enter" key after typing "Shinchan" in the YouTube search bar. Works the same as clicking the 
search button manually. Keys.RETURN is the same as pressing the Enter key on the keyboard.
"""

# Wait for the search results to load
time.sleep(2)

# Click on the second video
videos = driver.find_elements(By.XPATH, '//*[@id="video-title"]')  # Find all video titles
if len(videos) > 1:  # Check if at least 2 videos exist
    videos[1].click()  # Click the second video

# another 10
time.sleep(5)

# Open a new tab
driver.switch_to.new_window("tab")
  
# another webpage
driver.get("https://www.microsoft.com/en-in/microsoft-teams/log-in?msockid=3c1c420efb9b638710a55774fa736201")

# wait 5 seconds
time.sleep(5)

# another tab
driver.get("https://www.outlook.com")

# Close the browser
driver.close()  # Closes the current tab
# driver.quit()  # Closes all tabs and quits the browser