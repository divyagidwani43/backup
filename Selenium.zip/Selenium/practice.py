from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import time

# Set up the WebDriver (Replace with the path to your WebDriver)
driver = webdriver.Edge()  # Or use webdriver.Firefox() for Firefox
driver.maximize_window()

# Open a webpage
driver.get("https://www.google.com")
time.sleep(2)

# another webpage
driver.get("https://peopleplus.zoho.com/hrportal1524046337539/zp#home/myspace/overview-actionlist")
time.sleep(2)

# 3rd webpage
driver.get("https://www.microsoft.com/en-in/microsoft-teams/log-in?msockid=3c1c420efb9b638710a55774fa736201")
time.sleep(2)

# go back -1
driver.back()

# time pause
time.sleep(2)

# back more -2
driver.back()
time.sleep(2)

# forward
driver.forward()
time.sleep(2)

# refresh
driver.refresh()
time.sleep(2)

# another webpage
driver.get("https://www.youtube.com")

# search ninja
search_box = driver.find_element(By.NAME, "search_query")
search_box.send_keys("Ninja")
search_box.send_keys(Keys.RETURN)
time.sleep(2)

# play 4th video 
videos = driver.find_elements(By.XPATH, '//*[@id="video-title"]')  # Find all video titles
if len(videos) > 3:  # Check if at least 3 videos exist
    videos[3].click()  # Click the third video
time.sleep(2)

# go back again
driver.back()
time.sleep(2)

# another tab
driver.switch_to.new_window("tab")
driver.get("https://www.youtube.com")

# go to subscription by clicking subscription
try:
    subscriptions_button = driver.find_element(By.XPATH, '//a[@title="Subscriptions"]')
    subscriptions_button.click()
except:
    print("❌ Could not find the Subscriptions button.")

time.sleep(2)
# Close the browser
driver.quit()
