# String Methods: len(), split(), join()
text = "Hello, world!"
print(len(text))  # 13 (Total characters including space and punctuation)

words = text.split(", ")  
print(words)  # ['Hello', 'world!'] (Splitting by ', ')

joined_text = " - ".join(words)
print(joined_text)  # 'Hello - world!' (Joining with ' - ')

# String Formatting: f-strings, % formatting
name = "Alice"
age = 25

formatted1 = f"My name is {name} and I am {age} years old."
print(formatted1)  
# 'My name is Alice and I am 25 years old.'

formatted2 = "My name is %s and I am %d years old." % (name, age)
print(formatted2)  
# 'My name is Alice and I am 25 years old.'

# String Slicing and Indexing
s = "Python"
print(s[0])   # 'P' (First character)
print(s[-1])  # 'n' (Last character)

print(s[1:4])  # 'yth' (Characters from index 1 to 3)
print(s[:3])   # 'Pyt' (First three characters)
print(s[3:])   # 'hon' (From index 3 to end)
print(s[::-1]) # 'nohtyP' (Reversed string)

# Escape Characters
esc_text = "This is a \"quoted\" word."
print(esc_text)  
# 'This is a "quoted" word.' (Using \" to include quotes inside string)

newline_text = "Hello\nWorld"
print(newline_text)  
# 'Hello' (New line)
# 'World'

tabbed_text = "Hello\tWorld"
print(tabbed_text)  
# 'Hello    World' (Tab space between words)

backslash_text = "This is a backslash: \\ "
print(backslash_text)  
# 'This is a backslash: \'
#  The double backslash (\\) tells Python to treat the backslash literally, 
# so it's included in the output as a single backslash.

# Incorrect usage of a backslash with a quote without escaping
text = "This is a backslash: \ "
print(text)  # Error while scanning string literal
# In this case, the backslash before the quote is not escaped properly.
# Python tries to interpret it as an escape character for the quote,
# but it encounters an issue because the string is not closed properly. 
# This results in a syntax error.
