# Write a function count_vowels(s) that takes a string as input and returns the count of vowels (a, e, i, o, u - both uppercase and lowercase).
def count_vowels(s):
    count=0
    vowels="AEIOUaeiou"
    for letters in s:
        for vowel in vowels:
            # print(vowel)
            if(vowel==letters):
                print(f"{vowel} found")
                count+=1
    print(count)
count_vowels("divyaa")

user_input =input("Enter a string:")
print(f"count for vowels for user input : {count_vowels(user_input)}")