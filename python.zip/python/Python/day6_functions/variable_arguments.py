
# 5. Variable-Length Arguments (*args)
def sum_all(*numbers):
    print("Numbers type:",type(numbers))
    # The type of numbers is a tuple
    total = sum(numbers) #The sum() function in Python is a built-in function that takes an iterable (such as a list or tuple) and returns the sum of its elements.
    print("Sum:", total)

sum_all(1, 2, 3)
sum_all(10, 20, 30, 40, 50)

# 6. Variable-Length Keyword Arguments (**kwargs)
def print_details(**info):
    # **kwargs collects multiple named arguments into a dictionary
    print("Details type:", type(info))
    for key, value in info.items():
        print(f"{key}: {value}")

print_details(name="Alice", age=25, city="New York")
print_details(name="Bob", profession="Engineer")

# 7. Combining *args and **kwargs
def show_info(*args, **kwargs):
    # This function demonstrates using both *args and **kwargs together
    print("Arguments type:", type(args))
    print("Keyword arguments type:", type(kwargs))
    print("Positional arguments:", args)
    print("Keyword arguments:", kwargs)

show_info(1, 2, 3, name="Alice", age=25)

