# Exercise 1: Convert two lists into a dictionary
keys = ['Ten', 'Twenty', 'Thirty']
values = [10, 20, 30]
# {'Ten': 10, 'Twenty': 20, 'Thirty': 30}
dict={}
for i in range(len(keys)):
    dict[keys[i]] = values[i]
print(dict)

# Exercise 2: Merge two Python dictionaries into one
dict1 = {'Ten': 10, 'Twenty': 20, 'Thirty': 30}
dict2 = {'Thirty': 30, 'Fourty': 40, 'Fifty': 50}
# {'Ten': 10, 'Twenty': 20, 'Thirty': 30, 'Fourty': 40, 'Fifty': 50}
dict3={}
for keys,values in dict1.items():
    dict3[keys]=values
for keys,values in dict2.items():
    dict3[keys]=values
print(dict3)
# Exercise 3: Print the value of key ‘history’ from the below dict
sampleDict = {
    "class": {
        "student": {
            "name": "Mike",
            "marks": {
                "physics": 70,
                "history": 80
            }
        }
    }
}
print(sampleDict["class"]["student"]["marks"]["history"])

# Exercise 4: Initialize dictionary with default values
employees = ['Kelly', 'Emma']
defaults = {"designation": 'Developer', "salary": 8000}
# {'Kelly': {'designation': 'Developer', 'salary': 8000}, 'Emma': {'designation': 'Developer', 'salary': 8000}}
default={}
for i in range(len(employees)):
    default[employees[i]]=defaults
print(default)
# Exercise 5: Create a dictionary by extracting the keys from a given dictionary
sample_dict = {
    "name": "Kelly",
    "age": 25,
    "salary": 8000,
    "city": "New york"}

# Keys to extract
keys = ["name", "salary"]
# {'name': 'Kelly', 'salary': 8000}
dict5={}
for i in range(len(keys)):
    dict5[keys[i]]=sample_dict[keys[i]]
print(dict5)

# Exercise 6: Delete a list of keys from a dictionary
sample_dict = {
    "name": "Kelly",
    "age": 25,
    "salary": 8000,
    "city": "New york"
}

# Keys to remove
keys = ["name", "salary"]

for i in range(len(keys)):
    sample_dict.pop(keys[i])
print(sample_dict)
# Exercise 7: Check if a value exists in a dictionary
# Write a Python program to check if value 200 exists in the following dictionary.
sample_dict = {'a': 100, 'b': 200, 'c': 300}
# 200 present in a dict
for key, values in sample_dict.items():
    if values == 200:
        print("200 is there")

if(200 in sample_dict.values()):
    print("again")

# Exercise 8: Rename key of a dictionary
# Write a program to rename a key city to a location in the following dictionary.
sample_dict = {
  "name": "Kelly",
  "age":25,
  "salary": 8000,
  "city": "New york"
}


# Exercise 9: Get the key of a minimum value from the following dictionary
sample_dict = {
  'Physics': 82,
  'Math': 65,
  'history': 75
}
i=100
k=""
for keys, values in sample_dict.items():
    if(i>values):
        i=values
        k= keys
        
print(i,k)
# Exercise 10: Change value of a key in a nested dictionary
sample_dict = {
    'emp1': {'name': 'Jhon', 'salary': 7500},
    'emp2': {'name': 'Emma', 'salary': 8000},
    'emp3': {'name': 'Brad', 'salary': 500}
}
sample_dict["emp2"]["salary"]=8500
print(sample_dict)