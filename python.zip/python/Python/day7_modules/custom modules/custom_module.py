# Importing the custom module named 'my_module'
import my_module

# Using functions from the module

# Calling the 'add' function from 'my_module' to add 10 and 5
print(f"Addition: {my_module.add(10, 5)}")  # Output: 15

# Calling the 'subtract' function from 'my_module' to subtract 5 from 10
print(f"Subtraction: {my_module.subtract(10, 5)}")  # Output: 5

# Calling the 'multiply' function from 'my_module' to multiply 10 and 5
print(f"Multiplication: {my_module.multiply(10, 5)}")  # Output: 50

# Calling the 'divide' function from 'my_module' to divide 10 by 5
print(f"Division: {my_module.divide(10, 5)}")  # Output: 2.0

# Accessing the constant 'PI' from 'my_module'
print(f"Value of PI: {my_module.PI}")  # Output: 3.14159