# Importing specific functions and constants from the custom module 'my_module'
from my_module import add, divide, PI

# from my_module import *
# We can import everything from a module using * (wildcard), but it is not recommended as it can overwrite existing variables or functions.
# This is known as namespace pollution.

# Using the imported functions and constants

# Calling the 'add' function from 'my_module' to add 8 and 2
print(f"Sum: {add(8, 2)}")  # Output: 10

# Calling the 'divide' function from 'my_module' to divide 8 by 2
print(f"Division: {divide(8, 2)}")  # Output: 4.0

# Accessing the constant 'PI' from 'my_module'
print(f"PI Value: {PI}")  # Output: 3.14159