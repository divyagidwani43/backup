import random

# 1. Generating Random Floats
def get_random_float_0_1() -> float:
    """Returns a random float between 0 and 1."""
    return random.random()

def get_random_float_range(start: float, end: float) -> float:
    """Returns a random float between the given start and end values."""
    return random.uniform(start, end)

# Testing the functions
print("Random float between 0 and 1:", get_random_float_0_1())
print("Random float between 5 and 10:", get_random_float_range(5, 10))

# 2. Generating Random Integers
print("Random integer between 1 and 100:", random.randint(1, 100))  # Generates a random integer between 1 and 100
print("Random integer from range 1-10 with step 2:", random.randrange(1, 10, 2))  # Generates a random integer from range 1-10 with step 2

# 3. Selecting Random Elements
colors = ['red', 'blue', 'green', 'yellow']
print("Random choice from list:", random.choice(colors))  # Selects a random element from the list
#same as
random_index = random.randint(0, len(colors) - 1)
random_color = colors[random_index]
print("Random choice from list:", random_color)

print("Random sample of 2 elements:", random.sample(colors, 2))  # Selects a random sample of 2 elements from the list
print("Random choices allowing duplicates:", random.choices(colors, k=3))  # Selects 3 random elements from the list, allowing duplicates

# 4. Shuffling a List
numbers = [1, 2, 3, 4, 5]
random.shuffle(numbers)  # Shuffles the list in place
print("Shuffled list:", numbers)

# 5. Random Boolean Values
print("Random boolean value:", random.choice([True, False]))  # Selects a random boolean value (True or False)

# 6. Seeding Random Generator
random.seed(42)  # Seeds the random number generator with a specific value
print("Seeded random integer:", random.randint(1, 100))  # Generates a random integer between 1 and 100 using the seeded generator

# 7. Dice Roll Simulation
def roll_dice():
    return random.randint(1, 6)  # Simulates rolling a six-sided dice

print(f"You rolled a {roll_dice()}!")  # Prints the result of rolling the dice

# 8. Generating Random Gaussian Values (Normal Distribution)
print("Random value from normal distribution (mean=0, stddev=1):", random.gauss(0, 1))  # Generates a random value from a normal distribution with mean 0 and standard deviation 1

# 9. Generating Random Bytes
random_bytes = random.randbytes(5)  # Generates 5 random bytes
print("Random bytes:", random_bytes)

# 10. Simulating Coin Toss
def coin_toss():
    return "Heads" if random.choice([True, False]) else "Tails"  # Simulates a coin toss

print("Coin toss result:", coin_toss())  # Prints the result of the coin toss

# 11. Simulating Lottery Number Selection
def lottery_numbers():
    return sorted(random.sample(range(1, 50), 6))  # Selects 6 unique random numbers from 1 to 49 and sorts them

print("Lottery numbers:", lottery_numbers())  # Prints the selected lottery numbers