import sys  # Import the sys module

# 1. Get Python Version
print(f"Python version: {sys.version}")  # Returns full version details
print(f"Python version info: {sys.version_info}")  # Returns a tuple of version details

# 2. Command-Line Arguments (sys.argv)
# sys.argv stores the command-line arguments passed to the script
print(f"Script name: {sys.argv[0]}")  # First argument is always the script filename

# If additional arguments are passed, print them
if len(sys.argv) > 1:
    print(f"Arguments passed: {sys.argv[1:]}")
else:
    print("No additional command-line arguments provided.")

# Example usage in terminal:
# python sys_module_demo.py arg1 arg2 arg3
# Output: Script name: sys_module_demo.py
# Arguments passed: ['arg1', 'arg2', 'arg3']

# 3. Exiting a Program (sys.exit)
# sys.exit() is used to terminate the script immediately.
# Uncomment below lines to test:

# print("Before exiting...")
# sys.exit("Exiting program!")  # This will terminate the script
# print("This will not be printed.")  # This line will not execute

# 4. Python Module Search Path (sys.path)
# sys.path lists all directories where Python searches for modules
print("\nPython module search paths:")
for path in sys.path:
    print(path)

# 5. Standard Input, Output, and Error Streams
# sys.stdout (Standard Output)
sys.stdout.write("This message is printed using sys.stdout.write()\n")

# sys.stderr (Standard Error)
sys.stderr.write("This is an error message written to sys.stderr!\n")

# 6. Getting System Platform Information
print(f"\nOperating system platform: {sys.platform}")

# Output Example:
# 'win32'  -> Windows
# 'linux'  -> Linux
# 'darwin' -> macOS

# 7. Maximum Integer Size (sys.maxsize)
print(f"Maximum integer size: {sys.maxsize}")

# 8. Recursion Limit (sys.getrecursionlimit & sys.setrecursionlimit)
print(f"Current recursion limit: {sys.getrecursionlimit()}")

# To change the recursion limit (Use with caution!)
# sys.setrecursionlimit(2000)
# print(f"New recursion limit: {sys.getrecursionlimit()}")

# 9. Checking if the Script is Running in Interactive Mode
if hasattr(sys, 'ps1'):
    print("Running in interactive mode")
else:
    print("Running as a script")

# Summary:
# The sys module provides useful system-related functions, including:
# - Getting Python version
# - Handling command-line arguments
# - Managing system paths
# - Exiting the program
# - Working with standard input/output/error
# - Getting system and recursion limit details

print("\nEnd of sys module demo script.")