import pytest
from pages.login_page import LoginPage
import os
import time

def test_valid_login(driver):
    file_path = os.path.abspath("C:/Users/Dell/Desktop/python/Python/selenium/py_test/POM/static/login.html")  # Load local HTML file
    driver.get(f"file://{file_path}")

    login_page = LoginPage(driver)
    login_page.login("testuser", "password123")
    time.sleep(2)
    alert = driver.switch_to.alert
    assert "Login successful!" in alert.text
    alert.accept()
    time.sleep(2)
    
