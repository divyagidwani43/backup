from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("file://C:/Users/Dell/Desktop/python/Python/selenium/locating_web_elements/login.html")

time.sleep(3)

forgot_password_link = driver.find_element(By.LINK_TEXT, "Forgot Password?")

forgot_password_link.click()

time.sleep(3)

driver.quit()
