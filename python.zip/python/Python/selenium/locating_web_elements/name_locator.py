from selenium import webdriver
from selenium.webdriver.common.by import By
import time

driver = webdriver.Chrome()

driver.get("file://C:/Users/Dell/Desktop/python/Python/selenium/locating_web_elements/login.html")

time.sleep(3)

username = driver.find_element(By.NAME, "username")  # Changed to By.NAME
password = driver.find_element(By.NAME, "password")  # Changed to By.NAME
login_button = driver.find_element(By.TAG_NAME, "button")  # Locate button by tag name

username.send_keys("test_user1")
password.send_keys("securePass1234")
login_button.click()
time.sleep(3)

username.clear()
password.clear()

username.send_keys("test_user")
password.send_keys("securePass123")
login_button.click()

time.sleep(3)

driver.quit()
