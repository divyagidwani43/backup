import re

"""
Special Sequences & Escape Characters:

\b  → Word boundary
\B  → Not a word boundary
\D  → Not a digit
\W  → Not a word character
\S  → Not a whitespace character
"""

# \b → Word boundary (matches 'cat' as a whole word)
s1 = "The cat is sleeping. category"
p1 = r"\bcat\b"
p11 = r"\bsleeping\b"
match1 = re.findall(p1, s1)
match11 = re.findall(p11, s1)
print(r"Word boundary \b:", match1) 
print(r"Word boundary \b:", match11) 

# \B → Not a word boundary (matches 'cat' inside another word)
p2 = r"\Bcat\B"
match2 = re.findall(p2, s1)
print(r"Not a word boundary \B:", match2) 

# \D → Matches any non-digit character
s2 = "Phone: 123-456-7890"
p3 = r"\D+"
match3 = re.findall(p3, s2)
print(r"Non-digit \D:", match3)  

# \W → Matches any non-word character (opposite of \w)
s3 = "Hello, World!"
p4 = r"\W+"
match4 = re.findall(p4, s3)
print(r"Non-word character \W:", match4)  

# \S → Matches any non-whitespace character
s4 = "Hello   World!"
p5 = r"\S+"
match5 = re.findall(p5, s4)
print(r"Non-whitespace \S:", match5) 
