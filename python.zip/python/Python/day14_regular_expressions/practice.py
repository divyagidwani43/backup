import re

"""
Extract all numbers from the string
s1 = "Order 1234 was placed on 02-03-2025 at 5:45 PM."
Expected Output: ['1234', '02', '03', '2025', '5', '45']
"""
s1 = "Order 1234 was placed on 02-03-2025 at 5:45 PM."
p1 = r"\d+"
print("Extracted Numbers:", re.findall(p1, s1))



"""
Find all words that start with 'a' or 'A'
s2 = "Apple and banana are amazing fruits."
Expected Output: ['Apple', 'and', 'amazing']
"""
s2 = "Apple and banana are amazing fruits."
p2 = r"\b[Aa]\w*"
print("Words starting with 'a' or 'A':", re.findall(p2, s2))



"""
Find all words that end with 'ing'
s3 = "I am reading a book while running in the park."
Expected Output: ['reading', 'running']
"""
s3 = "I am reading a book while running in the park."
p3 = r"\b\w+ing\b"
print("Words ending with 'ing':", re.findall(p3, s3))



"""
Check if a string starts with 'Hello'
s4 = "Hello, how are you?"
Expected Output: 'Hello'
"""
s4 = "Hello, how are you?"
p4 = r"^Hello"
match_result4 = re.match(p4, s4)
if match_result4:
    print("String starts with 'Hello':", match_result4.group())


"""
Extract all email addresses from a string
s5 = "Contact us at support@email.com or sales@company.org for help."
Expected Output: ['support@email.com', 'sales@company.org']
"""
s5 = "Contact us at support@email.com or sales@company.org for help."
p5 = r"[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}"
print("Extracted Emails:", re.findall(p5, s5))



"""
Extract all words that contain only uppercase letters
s7 = "The USA and UK are great places. NASA explores space."
Expected Output: ['USA', 'UK', 'NASA']
"""
s7 = "The USA and UK are great places. NASA explores space."
p7 = r"\b[A-Z]{2,}\b"
print("Uppercase Words:", re.findall(p7, s7))


"""
Replace all multiple spaces with a single space
s8 = "Python    is  awesome!  Let's   code."
Expected Output: "Python is awesome! Let's code."
"""
s8 = "Python    is  awesome!  Let's   code."
p8 = r"\s+"
print("String after removing extra spaces:", re.sub(p8, " ", s8))


"""
Extract hashtags from a tweet
s9 = "Follow #Python and #Coding for daily updates!"
Expected Output: ['#Python', '#Coding']
"""
s9 = "Follow #Python and #Coding for daily updates!"
p9 = r"#\w+"
print("Extracted Hashtags:", re.findall(p9, s9))


"""
Split a string on commas, semicolons, and pipes (|)
s10 = "apple, orange; banana|grape"
Expected Output: ['apple', 'orange', 'banana', 'grape']
"""
s10 = "apple, orange; banana|grape"
p10 = r"[,;|]"
print("Split String:", re.split(p10, s10))


"""
extract all uppercase letters
"""
s23="HI here i am JILL"
p23=r"[A-Z]"
print(re.findall(p23,s23))


"""
Split a string on commas, semicolons, and pipes (|)
"""
s10 = "apple, orange; banana|grape"
p10 = r"[,;|]"
print(re.split(p10,s10))