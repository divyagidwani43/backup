import requests
from bs4 import BeautifulSoup

# Fetch webpage content
url = "https://example.com"
response = requests.get(url)

# Parse the HTML
soup = BeautifulSoup(response.text, "html.parser")

# Extract title
print(soup.title.text)

# Extract all links
for link in soup.find_all("a"):
    print(link.get("href"))
