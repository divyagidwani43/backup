from bs4 import BeautifulSoup

# Sample HTML document
html_doc = """
<html>
    <head>
        <title>Web Scraping Example</title>
    </head>
    <body>
        <h1>Welcome to My Website</h1>
        <p class="description">This is a sample paragraph.</p>
        <p class="info">Another paragraph with information.</p>

        <div class="container">
            <h2>Article List</h2>
            <ul>
                <li class="article">Article 1</li>
                <li class="article">Article 2</li>
                <li class="article">Article 3</li>
            </ul>
        </div>

        <div id="links">
            <a href="https://example.com/page1">Page 1</a>
            <a href="https://example.com/page2">Page 2</a>
            <a href="https://example.com/page3">Page 3</a>
        </div>

        <table>
            <tr>
                <th>Item</th>
                <th>Price</th>
            </tr>
            <tr>
                <td>Apple</td>
                <td>$1</td>
            </tr>
            <tr>
                <td>Banana</td>
                <td>$0.5</td>
            </tr>
        </table>
    </body>
</html>
"""

# Create a BeautifulSoup object
soup = BeautifulSoup(html_doc, "html.parser")

# Extract the full text of the webpage
print("Full Page Text:\n", soup.get_text(), "\n")

# Extract the title of the page
print("Page Title:", soup.title.text)

# Extract the first heading (h1)
print("Main Heading:", soup.h1.text)

# Extract all paragraphs
paragraphs = soup.find_all("p")
for i, para in enumerate(paragraphs, start=1):
    print(f"Paragraph {i}: {para.text}")

# Extract paragraphs based on class
description_text = soup.find("p", class_="description").text
print("\nDescription Paragraph:", description_text)

info_text = soup.find("p", class_="info").text
print("Info Paragraph:", info_text)

# Extract all list items under 'Article List'
articles = soup.find_all("li", class_="article")
print("\nArticles List:")
for article in articles:
    print("-", article.text)

# Extract all links
links = soup.find_all("a")
print("\nExtracted Links:")
for link in links:
    print(f"Text: {link.text}, URL: {link.get('href')}")

# Extract the table content
table_rows = soup.find_all("tr")
print("\nExtracted Table Data:")
for row in table_rows:
    columns = row.find_all("td")
    if columns:  # Ignore header row
        item = columns[0].text
        price = columns[1].text
        print(f"Item: {item}, Price: {price}")

# Extract the first link
first_link = soup.find("a").get("href")
print("\nFirst Link Extracted:", first_link)

# Extract all text from a specific div
container_text = soup.find("div", class_="container").get_text()
print("\nContainer Text:\n", container_text.strip())

# Extract only text without HTML tags
plain_text = soup.get_text(separator="\n", strip=True)
print("\nPlain Extracted Text:\n", plain_text)

# Count the number of elements
num_paragraphs = len(soup.find_all("p"))
num_links = len(soup.find_all("a"))
num_articles = len(soup.find_all("li", class_="article"))

print(f"\nTotal Paragraphs: {num_paragraphs}")
print(f"Total Links: {num_links}")
print(f"Total Articles: {num_articles}")
