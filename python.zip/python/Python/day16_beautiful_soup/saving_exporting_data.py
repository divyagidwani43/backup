import csv
import json
import openpyxl  # For Excel export
from bs4 import BeautifulSoup

# Sample HTML document
html_doc = """
<html>
    <head>
        <title>Sample Page</title>
    </head>
    <body>
        <h1>Main Heading</h1>
        <p class="desc">This is the first paragraph.</p>
        <p class="desc">This is the second paragraph.</p>
        
        <div class="content">
            <ul>
                <li>Item 1</li>
                <li>Item 2</li>
                <li>Item 3</li>
            </ul>
        </div>

        <table>
            <tr>
                <th>Name</th>
                <th>Age</th>
            </tr>
            <tr>
                <td>Alice</td>
                <td>25</td>
            </tr>
            <tr>
                <td>Bob</td>
                <td>30</td>
            </tr>
        </table>

        <footer>
            <p>Contact: info@example.com</p>
        </footer>
    </body>
</html>
"""

# Create BeautifulSoup object
soup = BeautifulSoup(html_doc, "html.parser")

# Extract Data
print("\nExtracting Data...")

# Extract paragraphs
paragraphs = [p.text for p in soup.find_all("p")]

# Extract list items
list_items = [li.text for li in soup.find_all("li")]

# Extract table data
table_data = []
table_rows = soup.find_all("tr")

# Extract table headers
headers = [header.text for header in table_rows[0].find_all("th")]
table_data.append(headers)  # Add headers to table data

# Extract table rows
for row in table_rows[1:]:
    table_data.append([cell.text for cell in row.find_all("td")])

# Extract contact info from footer
contact_info = soup.find("footer").p.text

# Save Data to CSV
print("\nSaving to CSV...")

with open("output.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerow(["Paragraphs"])
    for row in paragraphs:
        writer.writerow([row])

    writer.writerow([])  # Empty row for separation
    writer.writerow(["List Items"])
    for row in list_items:
        writer.writerow([row])

    writer.writerow([])  # Empty row
    writer.writerow(["Table Data"])
    writer.writerows(table_data)

print("CSV File Saved: output.csv")

# Save Data to JSON
print("\nSaving to JSON...")

json_data = {
    "paragraphs": paragraphs,
    "list_items": list_items,
    "table_data": table_data,
    "contact_info": contact_info
}

with open("output.json", "w") as file:
    json.dump(json_data, file, indent=4)

print("JSON File Saved: output.json")

# Save Data to Excel (XLSX)
print("\nSaving to Excel...")

# Create a workbook and sheets
workbook = openpyxl.Workbook()
sheet = workbook.active
sheet.title = "Extracted Data"

# Write paragraphs
sheet.append(["Paragraphs"])
for row in paragraphs:
    sheet.append([row])

sheet.append([])  # Empty row for separation

# Write list items
sheet.append(["List Items"])
for row in list_items:
    sheet.append([row])

sheet.append([])  # Empty row

# Write table data
sheet.append(["Table Data"])
for row in table_data:
    sheet.append(row)

workbook.save("output.xlsx")

print("Excel File Saved: output.xlsx")

# Save Data to TXT File
print("\nSaving to TXT...")

with open("output.txt", "w") as file:
    file.write("Paragraphs:\n")
    for row in paragraphs:
        file.write(row + "\n")

    file.write("\nList Items:\n")
    for row in list_items:
        file.write(row + "\n")

    file.write("\nTable Data:\n")
    for row in table_data:
        file.write(", ".join(row) + "\n")

    file.write("\nContact Info:\n" + contact_info)

print("TXT File Saved: output.txt")

# Print Extracted Data
print("\nExtracted Data Summary:")
print("Paragraphs:", paragraphs)
print("List Items:", list_items)
print("Table Data:", table_data)
print("Contact Info:", contact_info)

print("\nData Extraction and Export Complete!")
