# Create and write to a file
# Write "Hello, this is a test file." to test.txt.
import os


with open("test.txt","w")as txt:
    txt.write("Hello, this is a test file.\n")
    txt.write("Why this is a test file.")

# Read the file and display its content
# Print the content of test.txt.
with open("test.txt" ,"r") as txt:
    content=txt.read()
    print(content)

# Append text to the file
# Append "Appending new content!" to test.txt.
with open("test.txt", "a")as txt:
    txt.write("\nAppending new content!")

with open("test.txt" ,"r") as txt:
    content=txt.read()
    print("\ncontent")
    print(content)


# Count the number of words in the file
# Print the total word count in test.txt.
with open("test.txt" ,"r") as txt:
    content=txt.read()
    print("\nlength")
    print(len(content))


# Find a specific word in the file
# Check if the word "test" exists in test.txt.
with open("test.txt" ,"r") as txt:
    content=txt.read()
    if("test" in content):
        print("\nthere")

# Copy contents from one file to another
# Copy the content of test.txt to copy.txt.

# Read a file line by line and display it
# Print each line from test.txt one by one.
with open("test.txt" ,"r") as txt:
    content=txt.readline()
    print(content)
    print(txt.readline())
    print(txt.readline())

# Check if the file exists before opening
# Handle errors if the file does not exist.
if os.path.exists("test.txt"):
    print("yes")

# Rename the file
# Rename test.txt to renamed_test.txt.

# Delete the file

# Delete renamed_test.txt after confirmation.