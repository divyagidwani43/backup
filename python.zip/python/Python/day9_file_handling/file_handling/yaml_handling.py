import yaml  # Importing the PyYAML library for working with YAML files

try:
    # Step 1: Define a dictionary containing sample data
    yaml_data = {
        "name": "John Doe",  # Storing a name as a string
        "age": 30,  # Storing an age as an integer
        "city": "New York",  # Storing a city name as a string
        "skills": ["Python", "Machine Learning", "DevOps"]  
        # Storing a list of skills
    }

    # Step 2: Open a YAML file in write mode ('w') to store the dictionary
    # This will create the file if it doesn't exist, or overwrite it if it does.
    with open("data.yaml", "w") as yaml_file:
        yaml.dump(yaml_data, yaml_file, default_flow_style=False)  
        # Convert dictionary to YAML format and write it to the file in a readable structure

    print("YAML file 'data.yaml' has been written successfully.")

    # Step 3: Open the same YAML file in read mode ('r') to read its contents
    with open("data.yaml", "r") as yaml_file:
        loaded_data = yaml.safe_load(yaml_file) or {}
        # Load and parse the YAML data from the file into a Python dictionary

        print("\nYAML File Content:")
        print(loaded_data)  
        # Print the loaded dictionary to verify the written data

# Step 4: Error handling
except FileNotFoundError:
    print("Error: The YAML file was not found!")  
    # Handles cases where the file is missing when trying to read it
except yaml.YAMLError as e:
    print("YAML Error:", e)  
    # Handles any syntax errors or issues while parsing the YAML content
except Exception as e:
    print("An unexpected error occurred:", e)  
    # Handles any other unexpected exceptions
finally:
    print("\nYAML file handling complete.")  
    # This block executes regardless of whether an error occurs or not
