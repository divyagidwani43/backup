from functools import singledispatch

class MathOperations:
    """
    Class demonstrating method overloading using default arguments.
    """
    def add(self, a, b=0, c=0):
        return a + b + c

math_op = MathOperations()
print(math_op.add(5))        # One argument, uses default values for b and c
print(math_op.add(5, 10))    # Two arguments, default value for c
print(math_op.add(5, 10, 15)) # Three arguments, no default values used

class Calculator:
    """
    Class demonstrating method overloading using *args.
    """
    def add(self, *args):
        return sum(args)

calc = Calculator()
print(calc.add(5))             # Single argument
print(calc.add(5, 10))         # Two arguments
print(calc.add(5, 10, 15, 20)) # Multiple arguments

class Person:
    """
    Class demonstrating method overloading using **kwargs.
    """
    def details(self, **kwargs):
        """
        Prints key-value pairs of provided keyword arguments.
        """
        for key, value in kwargs.items():
            print(f"{key}: {value}")

p = Person()
p.details(name="Amit", age=25) 
p.details(name="Rohit", city="Delhi", profession="Engineer")

@singledispatch
def show(data):
    print("Default:", data)

@show.register(int)
def _(data):
    """
    Handles integer inputs.
    """
    print("Integer:", data)

@show.register(str)
def _(data):
    """
    Handles string inputs.
    """
    print("String:", data.upper())

@show.register(list)
def _(data):
    """
    Handles list inputs.
    """
    print("List:", [x * 2 for x in data])

show(10)        # Integer
show("hello")   # String
show([1, 2, 3]) # List
show(5.5)       # Default case

class Animal:
    """
    Parent class representing animals.
    """
    def make_sound(self):
        """
        Prints a generic animal sound.
        """
        print("Animal makes a sound")

class Dog(Animal):
    """
    Child class overriding make_sound method.
    """
    def make_sound(self):
        """
        Specific implementation for Dog.
        """
        print("Dog barks")

animal = Animal()
dog = Dog()
animal.make_sound()  # Parent class method

dog.make_sound()     # Overridden method in Dog class

class Parent:
    """
    Parent class with a show method.
    """
    def show(self):
        print("This is the parent class method")

class Child(Parent):
    """
    Child class overriding the show method but using super().
    """
    def show(self):
        super().show()  # Calls the parent method
        print("This is the child class method")

child = Child()
child.show()

class A:
    """
    Parent class in multilevel inheritance.
    """
    def show(self):
        print("This is the parent class method")

class B(A):
    """
    Intermediate class in multilevel inheritance.
    """
    def show(self):
        super().show()
        print("This is the child class method")

class C(B):
    """
    Grandchild class in multilevel inheritance.
    """
    def show(self):
        super().show()
        print("This is the grandchild class method")

c = C()
c.show()

class D:
    """
    First parent class in multiple inheritance.
    """
    def show(self):
        print("This is the first parent class method")

class E:
    """
    Second parent class in multiple inheritance.
    """
    def show(self):
        print("This is the second parent class method")

class F(D, E):
    """
    Child class in multiple inheritance.
    """
    def show(self):
        super().show()
        print("This is the child class method")

f = F()
f.show()

class G:
    """
    Parent class in hierarchical inheritance.
    """
    def show(self):
        print("This is the parent class method")

class H(G):
    """
    First child class in hierarchical inheritance.
    """
    def show(self):
        super().show()
        print("This is the first child class method")

class I(G): 
    """
    Second child class in hierarchical inheritance.
    """
    def show(self):
        super().show()
        print("This is the second child class method")

h = H()
i = I() 
h.show() 
i.show()
