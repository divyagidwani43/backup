""" 
Private attributes and methods are those that are not accessible outside the class.
We can make an attribute or method private by prefixing it with two underscores (__).
"""

class BankAccount:    
    def __init__(self, account_number, balance):
        self.__account_number = account_number  # Private attribute (cannot be accessed directly)
        self.__balance = balance  # Private attribute (cannot be accessed directly)
    
    def deposit(self, amount):
        if amount > 0:
            self.__balance += amount # Accessing private attribute
            print(f"Deposited {amount} New balance {self.__balance}")
        else:
            print("Deposit amount must be positive.")
    
    def withdraw(self, amount):
        if 0 < amount <= self.__balance:
            self.__balance -= amount 
            print(f"Withdrawn {amount}. New balance: {self.__balance}")
        else:
            print("Insufficient balance or invalid amount.")
    
    def get_balance(self):
        print("returning balance")
        return self.__balance
    
    def get_account_number(self):
        print("returning account number")
        return self.__account_number

account = BankAccount("123456789", 1000)
account.deposit(500)
account.withdraw(300)
print("Current Balance:", account.get_balance())
print("Account Number:", account.get_account_number())

print(account.get_balance())  # 1200
print(account.get_account_number())  # 123456789

# private method
class MyClass:
    def __init__(self):
        self.__private_method()
    
    def public_method(self):
        print("Public method")
    
    def __private_method(self):
        print("Private method") # This method can only be accessed within the class

obj = MyClass()
obj.public_method() # Public method output : Public method
# obj.__private_method()  # AttributeError: 'MyClass' object has no attribute '__private_method'
# to access private method, we can call it from within the class
obj._MyClass__private_method()  # output : Private method

# Example of using getter and setter methods to control access to private attributes
class Student:
    def __init__(self, name, age):
        self.__name = name
        self.__age = age
    
    def get_name(self):
        return self.__name
    
    def set_name(self, name):
        if len(name) > 0:
            self.__name = name
        else:
            print("Name cannot be empty.")
    
    def get_age(self):
        return self.__age
    
    def set_age(self, age):
        if age > 0:
            self.__age = age
        else:
            print("Age must be positive.")

student = Student("Alice", 20)
print(student.get_name())  # Alice
student.set_name("Bob")
print(student.get_name())  # Bob
student.set_name("")  # Name cannot be empty.
print(student.get_name())  # Bob

print(student.get_age())  # 20
student.set_age(25)
print(student.get_age())  # 25  
student.set_age(-5)  # Age must be positive.
print(student.get_age())  # 25

# Example of using property decorator to create getter and setter methods
class Student:
    def __init__(self, name, age):
        self.__name = name
        self.__age = age
    
    @property
    def name(self):
        return self.__name
    
    @name.setter
    def name(self, name):
        if len(name) > 0:
            self.__name = name
        else:
            print("Name cannot be empty.")
    
    """
    The property method is used to define a getter method for the attribute.
    """
    @property
    def age(self):
        return self.__age
    
    """
    The setter method is called when we try to set the value of the property. The setter method takes the new value as an argument.
    """
    @age.setter
    def age(self, age):
        if age > 0:
            self.__age = age
        else:
            print("Age must be positive.")

student = Student("Alice", 20)
print(student.name)  # Alice
student.name = "Bob"
print(student.name)  # Bob
print(student.age)  # 20
student.age = 25    
print(student.age)  # 25

# Example of using property decorator to create read-only properties
class Circle:
    def __init__(self, radius):
        self.__radius = radius
    
    @property
    def radius(self):
        return self.__radius
    
    @property
    def diameter(self):
        return 2 * self.__radius
    
    @property
    def area(self):
        return 3.14 * self.__radius ** 2
    
    @property
    def circumference(self):
        return 2 * 3.14 * self.__radius
    
circle = Circle(5)
print(circle.radius)  # 5   
print(circle.diameter)  # 10
print(circle.area)  # 78.5


# Example of using property decorator to create write-only properties
class Person:
    def __init__(self, name):
        self.__name = name
    
    @property
    def name(self):
        return self.__name
    
    @name.setter
    def name(self, name):
        self.__name = name
    
    @name.deleter
    def name(self):
        del self.__name

person = Person("Alice")
print(person.name)  # Alice
person.name = "Bob" # Set the value of the property
print(person.name)  # Bob   
del person.name
# print(person.name)  # AttributeError: 'Person' object has no attribute '_Person__name'

"""
Name mangling is a technique used to make private attributes and methods more secure by adding a prefix to their names.
Name mangling is a way to make private attributes and methods more secure by adding a prefix to their names.
"""
class MyClass:
    def __init__(self):
        self.__private_var = 10 # Private attribute
    
    def __private_method(self): # Private method used for name mangling that means it can be accessed within the class
        print("Private method") 

obj = MyClass()
print(obj._MyClass__private_var)  # 10
obj._MyClass__private_method()  # Private method
"""
it can be accessed then how private method is secure?
The purpose of name mangling is not to make private attributes and methods completely inaccessible from outside the class.
The purpose is to make it harder to access them accidentally and to prevent name clashes with attributes and methods in subclasses.
It is a convention rather than a security feature.
"""

# Game development example - preventing direct modification of health points
class Player:
    def __init__(self, name, health):
        self.__name = name
        self.__health = health
    
    def hit(self, damage):
        self.__health -= damage
        if self.__health <= 0:
            print(f"{self.__name} is dead.")
        else:
            print(f"{self.__name} was hit. Health: {self.__health}")

player1 = Player("Alice", 100)
player1.hit(20)  # Alice was hit. Health: 80
player1.hit(90)  # Alice is dead.

# player1.__health = 1000  # AttributeError: 'Player' object has no attribute '__health'
# player1.__name = "Bob"  # AttributeError: 'Player' object has no attribute '__name'