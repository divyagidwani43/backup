# SINGLE INHERITANCE
class Animal:
    """Parent class representing an animal."""
    def make_sound(self):
        """Method to print a generic animal sound."""
        print("Animal makes a sound")

class Dog(Animal):
    """Child class inheriting from Animal."""
    def bark(self):
        """Method specific to Dog class."""
        print("Dog barks")

dog = Dog()
dog.make_sound()  # Inherited method
dog.bark()        # Dog's own method


# MULTIPLE INHERITANCE
class Father:
    """Parent class representing a Father."""
    def work(self):
        """Method showing father goes to work."""
        print("Father goes to work")

class Mother:
    """Parent class representing a Mother."""
    def cook(self):
        """Method showing mother cooks."""
        print("Mother cooks food")

class Child(Father, Mother):
    """Child class inheriting from both Father and Mother."""
    def play(self):
        """Method specific to Child class."""
        print("Child plays games")

child = Child()
child.work()  # Inherited from Father
child.cook()  # Inherited from Mother
child.play()  # Child's own method


# MULTILEVEL INHERITANCE
class Grandfather:
    """Grandparent class representing wisdom."""
    def wisdom(self):
        """Method showing grandfather's wisdom."""
        print("Grandfather shares wisdom")

class Father(Grandfather):
    """Parent class inheriting from Grandfather."""
    def work(self):
        """Method showing father works."""
        print("Father goes to work")

class Son(Father):
    """Child class inheriting from Father (which inherits from Grandfather)."""
    def play(self):
        """Method specific to Son class."""
        print("Son plays sports")

son = Son()
son.wisdom()  # Inherited from Grandfather
son.work()    # Inherited from Father
son.play()    # Son's own method

# in multiple inheritance, if both parent functions have the same method name, the child class will inherit the method from the first parent class
# in the above example, if both Father and Mother classes have a work method, the Child class will inherit the work method from Father class
# another example of multiple inheritance
class A:
    def show(self):
        print("A class method")

class B:
    def show(self):
        print("B class method")

class C(A, B):
    def cshow(self):
        print("C class method")

c = C()
c.show()  # Output: A class method
# In the above example, the show method of class A is inherited because class A is inherited first in the class C definition
