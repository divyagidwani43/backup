import pandas as pd

# Filtering Data in Pandas
print("Filtering Data:")

data = {'Name': ['Alice', 'Bob', 'Charlie', 'David'],
        'Age': [25, 30, 35, 40],
        'Salary': [50000, 60000, 70000, 80000]}

df = pd.DataFrame(data)
print("Original DataFrame:")
print(df)

# Filtering rows where Age is greater than 30
print("\nRows where Age > 30:")
filtered_df = df[df['Age'] > 30]
print(filtered_df)

# Filtering rows where Salary is less than or equal to 60000
print("\nRows where Salary <= 60000:")
filtered_df2 = df[df['Salary'] <= 60000]
print(filtered_df2)

# Filtering with multiple conditions (Age > 25 and Salary > 50000)
print("\nRows where Age > 25 and Salary > 50000:")
filtered_df3 = df[(df['Age'] > 25) & (df['Salary'] > 50000)]
print(filtered_df3)