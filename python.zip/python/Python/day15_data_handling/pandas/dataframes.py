import pandas as pd

"""
A Pandas DataFrame is a 2-dimensional data structure, like a 2D array or a table with rows and columns.
"""

# Creating a DataFrame
data = {
  "calories": [420, 380, 390],
  "duration": [50, 40, 45]
}
df = pd.DataFrame(data)
print("Original DataFrame:\n", df)  

# Locating a single row
print("\nLocating a single row at index 0:\n", df.loc[0])

# Locating multiple rows
print("\nLocating multiple rows at indices 0 and 1:\n", df.loc[[0, 1]])

# Creating a DataFrame with custom row indices
df = pd.DataFrame(data, index=["day1", "day2", "day3"])
print("\nDataFrame with custom row labels:\n", df)

# Locating a row by custom index
print("\nLocating row with index 'day2':\n", df.loc["day2"])
print("\nLocating rows with indices 'day2' and 'day3':\n",df.loc[["day2","day3"]])