import pandas as pd

"""
A Pandas Series is like a column in a table.
"""
values = [10, 20, 30, 40]
series1 = pd.Series(values)
print(series1)
print(series1[0])  
# If nothing else is specified, the values are labeled with their index number. First value has index 0, second value has index 1 etc.

# Creating Series with custom index
series_custom1 = pd.Series(values, index=['a', 'b', 'c', 'd'])
print(series_custom1)
print(series_custom1['a'])

# Key/Value Objects as Series
calories_dict = {"day1": 420, "day2": 380, "day3": 390}
series_dict = pd.Series(calories_dict)
print(series_dict)
print(series_dict["day1"])

# DataFrames
data_dict = {
  "calories": [420, 380, 390],
  "duration": [50, 40, 45]
}
df1 = pd.DataFrame(data_dict)
print(df1)

# Performing basic operations on Series
print("\nBasic Operations on Series:")
print("Sum of Series:", series1.sum())
print("Mean of Series:", series1.mean())
print("Maximum value in Series:", series1.max())
print("Minimum value in Series:", series1.min())

# Applying functions to Series
print("\nApplying Functions:")
print("Square of each element:")
print(series1.apply(lambda num: num ** 2))
