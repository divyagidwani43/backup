import numpy as np

# Checking the Data Type of an Array
arr15 = np.array([1, 2, 3, 4])
print(arr15.dtype)
arr16 = np.array(['apple', 'banana', 'cherry'])
print(arr16.dtype)

# Creating Arrays With a Defined Data Type
arr17 = np.array([1, 2, 3, 4], dtype='S')
print(arr17)
print(arr17.dtype)
arr18 = np.array([1, 2, 3, 4], dtype='i4')
print(arr18)
print(arr18.dtype)

# Converting Data Type on Existing Arrays
arr19 = np.array([1.1, 2.1, 3.1])
newarr = arr19.astype('i')
print(newarr)
print(newarr.dtype)
arr20 = np.array([1, 0, 3])
newarr2 = arr20.astype(bool)
print(newarr2)
print(newarr2.dtype)

