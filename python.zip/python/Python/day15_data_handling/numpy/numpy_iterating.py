import numpy as np
# NumPy Array Iterating
arr28 = np.array([1, 2, 3])
for x in arr28:
  print(x)

arr29 = np.array([[1, 2, 3], [4, 5, 6]])
for x in arr29:
  print(x)
for y in x:
    print(y)
  
arr30 = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
for x in arr30:
  print(x)
for y in x:
  print(y)
for z in y:
  print(z)

for x in arr30:
  for y in x:
    for z in y:
      print(z)

# Iterating Arrays Using nditer()
arr31 = np.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]]])
for x in np.nditer(arr31):
  print(x)

# Iterating Array With Different Data Types
arr32 = np.array([1, 2, 3])
for x in np.nditer(arr32, flags=['buffered'], op_dtypes=['S']):
  print(x)

# Iterating With Different Step Size
arr33 = np.array([[1, 2, 3, 4], [5, 6, 7, 8]])
for x in np.nditer(arr33[:, ::2]):
  print(x)

# Enumerated Iteration Using ndenumerate()
arr34 = np.array([1, 2, 3])
for idx, x in np.ndenumerate(arr34):
  print(idx, x)

arr35 = np.array([[1, 2, 3, 4], [5, 6, 7, 8]])
for idx, x in np.ndenumerate(arr35):
  print(idx, x)

