import numpy as np

# Array Indexing
arr9 = np.array([1, 2, 3, 4])
print(arr9[0])
print(arr9[2] + arr9[3])

# Access 2-D Arrays
arr10 = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('2nd element on 1st row: ', arr10[0, 1])
print('5th element on 2nd row: ', arr10[1, 4])
print('adding two elements', arr10[0, 1] + arr10[1, 4])

#  Access 3-D Arrays
arr11 = np.array([[[1, 2, 3], [4, 5, 6]], [[7, 8, 9], [10, 11, 12]]])
print("accessing 3d array ",arr11[1, 1, 2])
print(arr11[0, 1, 2])

# Negative Indexing
arr12 = np.array([[1,2,3,4,5], [6,7,8,9,10]])
print('Last element from 2nd dim: ', arr12[1, -1])
print('Last element from 1st dim: ', arr12[0, -1])
print('second last element from 1st dim: ', arr12[0, -2])

# Slicing
# We pass slice instead of index like this: [start:end].
# We can also define the step, like this: [start:end:step].
arr13 = np.array([1, 2, 3, 4, 5, 6, 7])
print(arr13[1:5])
print(arr13[4:]) # Slice elements from index 4 to the end of the array
print(arr13[:4]) # Slice elements from the beginning to index 4 
print(arr13[-3:-1]) # Slice from the index 3 from the end to index 1 from the end
print(arr13[1:5:2]) # Return every other element from index 1 to index 5
print(arr13[::2]) # Return every other element from the entire array

# Slicing 2-D Arrays
arr14 = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])
print(arr14[1, 1:4]) # From the second element, slice elements from index 1 to index 4 (not included)
print(arr14[0:2, 2])
print(arr14[0:2, 1:4])
