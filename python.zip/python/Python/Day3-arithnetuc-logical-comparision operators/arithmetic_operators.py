# + (Addition): Adds two operands.
print(5 + 3)  # 8

# - (Subtraction): Subtracts the second operand from the first.
print(5 - 3)  # 2

# * (Multiplication): Multiplies two operands.
print(5 * 3)  # 15

# / (Division): Divides the first operand by the second, returns a float.
print(5 / 2)  # 2.5

# // (Floor Division): Divides the first operand by the second and rounds down to the nearest integer.
print(5 // 2)  # 2

# % (Modulo): Returns the remainder of the division.
print(5 % 2)  # 1

# ** (Exponentiation): Raises the first operand to the power of the second.
print(5 ** 2)  # 25