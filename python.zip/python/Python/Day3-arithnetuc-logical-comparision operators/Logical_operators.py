# Using 'and' operator
(5 > 3) and (2 < 4)

# Using 'or' operator
(5 < 3) or (2 > 4)

# Using 'not' operator
not(5 > 3)

# ex02
age = int(input("Enter your age: "))
income = int(input("Enter your income: "))
# solu
if (age >= 18) and (income >= 25000):
    print("eligible")
else:
    print("NOT eligible")