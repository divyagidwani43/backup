# is not: Returns True if both operands refer to different objects.
x = [1, 2, 3]
y = [1, 2, 3]
print(x is not y)  # True (they are different objects in memory)

# is: Returns True if both operands refer to the same object.
x = [1, 2, 3]
y = x
print(x is y)  # True (both refer to the same object in memory)
