# in: Returns True if the value is found in the sequence.
'a' in 'apple'

'a' not in 'apple'  # false

# not in: Returns True if the value is not found in the sequence.
'b' not in 'apple'

# Ex-1
numbers = [10, 20, 30, 40, 50]

# x = input("Enter a number to check: ")
# error convert to int 
num = input("Enter a number: ")  # Suppose user enters 10
print(type(num))  # Output: <class 'str'>

x = int(input("Enter a number to check: "))

if x in numbers:
    print(x, "is in the list.")
else:
    print(x, "is NOT in the list.")