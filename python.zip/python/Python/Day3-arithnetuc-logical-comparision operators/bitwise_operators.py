5 | 3  # | (OR): Performs bitwise OR operation
5 ^ 3  # ^ (XOR): Performs bitwise XOR operation (exclusive OR)
5 << 1  # << (Left Shift): Shifts the bits to the left
5 >> 1  # >> (Right Shift): Shifts the bits to the right
5 & 3  # & (AND): Performs bitwise AND operation