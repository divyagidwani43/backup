# You can create a set by placing comma-separated values inside curly braces {} or by using the set() function.
# Sets are unordered, so you cannot access items by index.
# Sets are mutable, so you can add or remove items.

# Creating a set using curly braces
my_set = {1, 2, 3, 4, 5}
print(my_set)  # Output: {1, 2, 3, 4, 5}

# Creating a set using the set() function
another_set = set([1, 2, 3, 4, 5])
print(another_set)  # Output: {1, 2, 3, 4, 5}

# You can also use set() to convert other iterable types (e.g., list, tuple) into a set.
# Converting a list to a set
my_list = [1, 2, 3, 4, 5, 5, 6]
my_set_from_list = set(my_list)
print("Set from list:", my_set_from_list)  # Output: {1, 2, 3, 4, 5, 6}

# Converting a tuple to a set
my_tuple = (1, 2, 3, 4, 5, 5, 6)
my_set_from_tuple = set(my_tuple)
print("Set from tuple:", my_set_from_tuple)  # Output: {1, 2, 3, 4, 5, 6}

# Converting a string to a set
my_string = "hello"
my_set_from_string = set(my_string)
print("Set from string:", my_set_from_string)  # Output: {'h', 'e', 'l', 'o'}


# Adding an item to a set
my_set.add(6)
print(my_set)  # Output: {1, 2, 3, 4, 5, 6}

# Removing an item from a set
my_set.remove(6)
print(my_set)  # Output: {1, 2, 3, 4, 5}

# Iterating over a set
for item in my_set:
    print(item)
# Output:
# 1, 2, 3, 4, 5

# Checking if an item is in a set
print(3 in my_set)  # Output: True
print(6 in my_set)  # Output: False

# Finding the length of a set
print(len(my_set))  # Output: 5

# Combining two sets
set1 = {1, 2, 3}
set2 = {3, 4, 5}
combined_set = set1.union(set2)
print(combined_set)  # Output: {1, 2, 3, 4, 5}

# Finding the intersection of two sets
intersection_set = set1.intersection(set2)
print(intersection_set)  # Output: {3}

# Finding the difference between two sets
difference_set = set1.difference(set2)
print(difference_set)  # Output: {1, 2}

# Finding the symmetric difference between two sets
symmetric_difference_set = set1.symmetric_difference(set2)
print(symmetric_difference_set)  # Output: {1, 2, 4, 5}

# Checking if a set is a subset of another set
subset = {1, 2}
print(subset.issubset(set1))  # Output: True

# Checking if a set is a superset of another set
superset = {1, 2, 3, 4, 5}
print(superset.issuperset(set1))  # Output: True

# Creating an empty set using set()
empty_set = set()
print(empty_set)  # Output: set()

# Adding items to an empty set
empty_set.add(1)
empty_set.add(2)
print(empty_set)  # Output: {1, 2}

# Adding items to a set using a loop
dynamic_set = set()
for i in range(5, 11):
    dynamic_set.add(i)
print(dynamic_set)  # Output: {5, 6, 7, 8, 9, 10}
