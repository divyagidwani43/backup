class Car:
    wheels = 4  # Class attribute (shared by all instances)

    def __init__(self, brand, model):
        # Constructor - Called when an object is created Initialize instance attributes
        # self refers to the instance itself
        # self.attribute_name = value
        # self.___cost = 1000 # Private attribute can't be accessed outside the class
        # Instance Methods (self) - Require self as the first parameter (which refers to the instance itself).
        print(f"A new car object is created. { brand, model}")
        self.brand = brand  # Attribute
        self.model = model  # Attribute
        self.__margin = 600 # Private attribute can't be accessed outside the class The profit margin for the car, private attribute for internal us
        self._discount = 100 # Protected attribute can be accessed outside the class but not recommended
        self.salecost = 1000 # Public attribute can be accessed outside the class

    # Method (using the object)
    def display_info(self):
        # Instance Methods (self) - Require self as the first parameter (which refers to the instance itself).
        print(f"calling display info () This car is a {self.brand} {self.model}.")

    @classmethod
    def change_car(any_name_accessing_cLass, new_wheels):  # Class method
        """
        Operate on the class itself, not individual objects.
        Can modify class attributes (shared by all instances).
        Use @classmethod decorator and take cls as the first parameter (which refers to the class).
        """
        any_name_accessing_cLass.wheels = new_wheels
    
    @staticmethod
    def honk():  # Static method
        """
        Independent of both instance and class attributes.
        Behave like regular functions, but are defined inside a class.
        Use @staticmethod decorator and do not take self or cls as parameters
        """
        print("Beep beep!")
    
    def return_margin(self):
        return self.___margin # Output: 1000 returns the value of private attribute
    
    def __str__(self):
        # Special method that returns a string representation of the object
        return f"{self.brand} {self.model}" # Output: Toyota Corolla
    
    def __repr__(self):
        return f"{self.brand} {self.model}"

    def __del__(self): # Destructor
        print(f"The car object {self.brand} {self.model} is destroyed.")


# Creating objects
my_car = Car("Toyota", "Corolla")
my_car.display_info()  

# Accessing instance attributes
print(my_car.brand)  # Output: Toyota

# Modifying an instance attribute
my_car.brand = "Honda"
print(my_car.brand)  # Output: Honda

# Accessing class attributes
print(my_car.wheels)  # Output: 4

# Accessing private attribute  
# print(my_car.___margin) # Output: AttributeError: 'Car' object has no attribute '___margin' 
print(my_car.return_margin()) # Output: 1000

# Accessing protected attribute
print(my_car._discount) # Output: 100 can be accessed but not recommended

# Accessing public attribute
print(my_car.salecost) # Output: 1000 can be accessed

# Using the __str__ method
print(my_car)  # Output: Honda Corolla

# Deleting an object
del my_car  # Output: The car object Toyota Corolla is destroyed.
# my_car.display_info()  # Output: NameError: name 'my_car' is not defined

Car("bmw", "m-series").display_info() 

# Accessing a class attribute
print(Car.wheels)  # Output: 4

# Changing a class attribute
Car.wheels = 6
print(Car.wheels)  # Output: 6

# Using a class method to change a class attribute
Car.change_car(8)
print(Car.wheels)  # Output: 8

# Using a static method
Car.honk()  # Output: Beep beep!

# Inheritance
class ElectricCar(Car):
    def __init__(self, brand, model, battery):
        print("A new electric car object is created using inheritance.")
        super().__init__(brand, model) # Call the parent class constructor using super()
        self.battery = battery
        # self.___cost = 1000 # Private attribute can't be accessed outside the class

    def display_info(self):
        print(f"calling diaply info() This electric car is a {self.brand} {self.model} with a {self.battery} kWh battery.")

my_electric_car = ElectricCar("Tesla", "Model S", 100)
my_electric_car.display_info()  # Output: This electric car is a Tesla Model S with a 100 kWh battery.

# isinstance() function
# Check if an object is an instance of a class or its subclass
# isinstance(object, class)
print(isinstance(my_electric_car, ElectricCar))  # Output: True
print(isinstance(my_electric_car, Car))  # Output: True
print(isinstance(my_electric_car, object))  # Output: True

# issubclass() function
# Check if a class is a subclass of another class
# issubclass(subclass, class)
print(issubclass(ElectricCar, Car))  # Output: True 

# Method Overriding
my_electric_car.display_info()  # Output: This electric car is a Tesla Model S with a 100 kWh battery.

# Multiple inheritance
class HybridCar(Car, ElectricCar):
    def __init__(self, brand, model, battery, engine):
        print("A new hybrid car object is created using multiple inheritance.")
        Car.__init__(self, brand, model) # Call the parent class constructor using class name
        ElectricCar.__init__(self, brand, model, battery) # Call the parent class constructor using class name
        self.engine = engine

    def display_info(self):
        print(f"calling display info() This hybrid car is a {self.brand} {self.model} with a {self.battery} kWh battery and a {self.engine} engine.")

my_hybrid_car = HybridCar("Toyota", "Prius", 1.3, "1.8L")