# Task 5: Create a Library System
# Create a Library class with:
# A class attribute books = [] (a list to store books).
# Methods:
# add_book(book_name): Adds a book to the list.
# remove_book(book_name): Removes a book if it exists.
# display_books(): Prints all available books.
# Create an instance and test the methods.
class Library:
    books = []
    lent_books = []
    
    def add_book(self, book_name):
        """Adds a book to the library if it does not already exist."""
        if book_name in self.books or book_name in self.lent_books:
            if book_name in self.lent_books:
                print("Book is already lent")
            else:
                print("Book already exists")
        self.books.append(book_name)    
    
    def remove_book(self, book_name):
        """Removes a book from the library if it exists."""
        if book_name in self.books or book_name in self.lent_books:
            self.books.remove(book_name)
        else:
            print("Book not found")
    
    def display_books(self):
        """Displays all available books in the library."""
        print("Available books:")
        for book in self.books:
            print(book)

    def lend_book(self, book_name):
        """Lends a book to a user if it is available."""
        if book_name in self.books:
            self.lent_books.append(book_name)
            self.books.remove(book_name)
            print(f"{book_name} lent")
        else:
            print("Book not found")

    def return_book(self, book_name):
        """Returns a lent book to the library."""
        if book_name in self.lent_books:
            self.books.append(book_name)
            self.lent_books.remove(book_name)
            print(f"{book_name} returned")
        else:
            print("Book not found")

lib = Library()
lib.add_book("Python for Beginners")
lib.add_book("Python for Experts")
lib.add_book("Python for Data Science")
lib.display_books()
lib.lend_book("Python for Beginners")
lib.display_books()
lib.return_book("Python for Beginners")
lib.display_books()