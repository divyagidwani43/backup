def uppercase_decorator(func):
    def wrapper():
        result = func()
        return result.upper()  
    return wrapper

def exclamation_decorator(func):
    def wrapper():
        result = func()
        return result + "!!!" 
    return wrapper

@uppercase_decorator
@exclamation_decorator
def greet():
    return "hello"

print(greet())

def greet_again():
    return "konichiwa"

greet_again = uppercase_decorator(exclamation_decorator(greet_again))
print(greet_again())

"""
Create two decorators:
@bold_decorator → Wraps the function output in ** (Markdown-style bold).
@italic_decorator → Wraps the function output in _ (Markdown-style italic).
Then, apply both decorators to a function format_text() that returns a string "Hello, Python!".
"""
def bold_decorator(func):
    def wrapper():
        result = func()
        return "**" + result + "**"
    return wrapper

def italic_decorator(func):
    def wrapper():
        result = func()
        return "_" + result + "_"
    return wrapper

@bold_decorator
@italic_decorator
def format_text():
    return "Hello, Python!"

print(format_text())


"""
Create two decorators:
@validate_input → Checks if the function argument is a non-empty string. If not, prints "Invalid input!" and returns None.
@capitalize_text → Converts the function’s output to uppercase.
Apply both decorators to a function greet(name), which returns "hello, {name}!".
"""
def validate_input(func):
    def wrapper(name):
        if name =="":
            print("Invalid input!")
            return None
        return func(name)
    return wrapper

def capitalize_text(func):
    def wrapper(name):
        result = func(name)
        return result.upper()
    return wrapper

@validate_input
@capitalize_text
def my_name(name):  
    return f"hello, {name}!"
print(my_name("divya"))

def p1(namee):
    return f"hello, {namee}!"
p2=validate_input(capitalize_text(p1))
print(p2("himani"))

