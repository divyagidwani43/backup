"""A decorator is a function that modifies the behavior of another function
without changing its actual code. It allows us to wrap additional functionality
around an existing function."""

def my_decorator(func):
    def wrapper():
        print("Before the function call")
        func()  
        print("After the function call")
    return wrapper  

@my_decorator 
def say_hello():
    print("Hello, World!")

say_hello()

def here():
    print("hiiiiiiiii")
# Without the @ syntax, we could also apply the decorator manually like this:
decorated_func = my_decorator(here)
decorated_func()

def greet():
    print("Greetings!")

decorated_greet = my_decorator(greet)  # Manually decorating the function
decorated_greet() 


def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner

@make_pretty
def ordinary():
    print("I am ordinary")

ordinary()  

def smart_divide(func):
    def inner(a, b):
        print("I am going to divide", a, "and", b)
        if b == 0:
            print("Whoops! cannot divide")
            return

        return func(a, b)
    return inner

@smart_divide
def divide(a, b):
    print(a/b)

divide(2,5)
divide(2,0)

def star(func):
    def inner(*args, **kwargs):
        print("*" * 15)
        func(*args, **kwargs)
        print("*" * 15)
    return inner
def percent(func):
    def inner(*args, **kwargs):
        print("%" * 15)
        func(*args, **kwargs)
        print("%" * 15)
    return inner

@star
@percent
def printer(msg):
    print(msg)
printer("Hello")