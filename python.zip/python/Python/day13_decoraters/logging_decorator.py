def log(func):
    def wrapper(*args, **kwargs):
        print(f"Calling {func.__name__} with {args}, {kwargs}")
        return func(*args, **kwargs)
    return wrapper

@log
def add(a, b):
    return a + b
print(add(3, 5))

@log
def multiply(a, b):
    return a * b
print(multiply(2, 4))

@log
def divide(a, b):
    return a / b
print(divide(10, 2))