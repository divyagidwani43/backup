// Applying inline CSS using JavaScript
