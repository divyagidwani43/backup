// Adding and removing CSS classes dynamically
