// Getting computed styles of an element
