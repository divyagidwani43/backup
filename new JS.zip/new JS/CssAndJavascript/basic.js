// inlineStyles.js – Applying styles directly using element.style

// classList.js – Adding, removing, and toggling classes with .classList

// getComputedStyle.js – Retrieving styles using window.getComputedStyle()

// cssVariables.js – Using and modifying CSS variables (--custom-color) in JS

// eventBasedStyling.js – Changing styles dynamically on events like hover, click, etc.

// animation.js – Handling CSS animations/transitions with JavaScript

// darkModeToggle.js – Implementing dark mode using CSS and JavaScript

// mediaQueries.js – Using matchMedia for responsive design

// injectCSS.js – Dynamically adding/removing stylesheets using JS

// cssFrameworks.js – Using JavaScript to interact with Tailwind, Bootstrap, etc.