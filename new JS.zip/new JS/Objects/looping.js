// Looping through properties (for...in)
let person = {
    name: "Alice",
    age: 25,
    city: "New York"
};

for (let key in person) {
    console.log(key, ":", person[key]);
}

// Getting keys & values (Object.keys(), Object.values(), Object.entries())

let user = {
    name: "Alice",
    age: 25,
    city: "New York"
};

console.log(Object.entries(user));
// [
//     ["name", "Alice"],
//     ["age", 25],
//     ["city", "New York"]
// ]
for (let arr of Object.entries(user)){
    console.log(arr)
}
// (2) ['name', 'Alice']
// (2) ['age', 25]
// (2) ['city', 'New York']

for (let [key, value] of Object.entries(user)){
    console.log(value)
}
