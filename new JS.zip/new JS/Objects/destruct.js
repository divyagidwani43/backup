// Extracting values from an object into variables
let personInfo = { firstName: "Alice", years: 25, location: "New York" };
let { firstName, years, location } = personInfo;
console.log(firstName);  // Alice
console.log(years);      // 25
console.log(location);   // New York

// Renaming extracted variables
let studentDetails = { fullName: "John Doe", grade: "A", section: "G" };
let { fullName: studentName, grade: studentGrade } = studentDetails;
console.log(studentName); // John Doe
console.log(studentGrade); // A

// Providing a default value for a missing property
let userProfile = { userHandle: "Sam" };
let { userHandle, userRole = "User" } = userProfile;
console.log(userHandle); // Sam
console.log(userRole);   // User (default value)

// Using the rest operator to store remaining properties
let productInfo = { productId: 101, productName: "Laptop", cost: 1500, brand: "Dell" };
let { productName, cost, ...extraDetails } = productInfo;
console.log(productName);  // Laptop
console.log(cost);         // 1500
console.log(extraDetails); // { productId: 101, brand: "Dell" }
