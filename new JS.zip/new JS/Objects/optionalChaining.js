let user = { name: "Alice", address: { city: "Paris" } };

console.log(user.address.city); // ✅ "Paris"
console.log(user.contact.phone); // ❌ ERROR (contact is undefined)
console.log(user.contact?.phone); // ✅ undefined (No error)
