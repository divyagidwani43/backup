// Methods like Object.keys(), Object.values(), Object.entries()
let person = {
    name: "Alice",
    age: 25,
    greet: function() {
        return `Hello, my name is ${this.name}!`;
    }
};

console.log(person.greet()); // ✅ "Hello, my name is Alice!"
