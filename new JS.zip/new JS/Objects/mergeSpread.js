let obj1 = { name: "Alice", age: 25 };
let obj2 = { city: "New York", country: "USA" };
let mergedObj = { ...obj1, ...obj2 };
console.log(mergedObj);  
// { name: "Alice", age: 25, city: "New York", country: "USA" }


let objA = { name: "John", age: 30 };
let objB = { age: 35, city: "London" };
let combined = { ...objA, ...objB };
console.log(combined);  
// { name: "John", age: 35, city: "London" } (age is overwritten)

let originalObj = { x: 10, y: 20 };
let clonedObj = { ...originalObj };
console.log(clonedObj);  
// { x: 10, y: 20 }
