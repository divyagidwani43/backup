// Explain prototypes and prototypal inheritance
