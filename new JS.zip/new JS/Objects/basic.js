// Creating an object
let person = {
    name: "Alice",
    age: 25,
    isStudent: true
};

// Accessing properties
console.log(person.name);   // ✅ "Alice"
console.log(person["age"]); // ✅ 25

// Adding & modifying properties
person.city = "New York";
person.age = 26;
console.log(person);

// Deleting a property
delete person.isStudent;
console.log(person);

// Checking if property exists
console.log("age" in person); // ✅ true
console.log(person.hasOwnProperty("city")); // ✅ true
