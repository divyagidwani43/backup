let demoObject = {
    name: "Alice",
    age: 30,
    
    // Regular function: `this` refers to the object
    showInfo: function () {
        console.log(`Name: ${this.name}, Age: ${this.age}`);
    },

    // Arrow function: `this` does NOT refer to the object, but to the surrounding scope (window/global)
    showInfoArrow: () => {
        console.log(`Name: ${this.name}, Age: ${this.age}`); // Undefined
    },

    // Method inside a nested function using a workaround to access `this`
    showInfoNested: function () {
        let self = this; // Save reference to `this`
        function innerFunction() {
            console.log(`Nested Function - Name: ${self.name}, Age: ${self.age}`);
        }
        innerFunction();
    },
    // If innerFunction is an arrow function, it will automatically inherit this from its surrounding scope, meaning you don't need to store this in a self variable.

    // `this` inside a method called with call()
    showWithCall: function (city) {
        console.log(`${this.name} lives in ${city}`);
    },

    // `this` inside a method called with apply()
    showWithApply: function (country) {
        console.log(`${this.name} is from ${country}`);
    },

    // `this` inside a method bound with bind()
    showWithBind: function () {
        let boundFunction = function () {
            console.log(`Bound Function - Name: ${this.name}, Age: ${this.age}`);
        }.bind(this);
        boundFunction();
    },

    // `this` in a setTimeout (regular function loses `this`, arrow function retains it)
    showWithTimeout: function () {
        setTimeout(function () {
            console.log(`setTimeout - Name: ${this.name}, Age: ${this.age}`); // Undefined
        }, 1000);

        setTimeout(() => {
            console.log(`Arrow Timeout - Name: ${this.name}, Age: ${this.age}`); // Works correctly
        }, 1000);
    }
};

// Calling methods
demoObject.showInfo();               // Works ✅
demoObject.showInfoArrow();          // Undefined ❌
demoObject.showInfoNested();         // Works ✅
demoObject.showWithCall.call(demoObject, "New York"); // Works ✅
demoObject.showWithApply.apply(demoObject, ["USA"]); // Works ✅
demoObject.showWithBind();           // Works ✅
demoObject.showWithTimeout();        // Timeout example

// this in Objects

// this inside methods

// Arrow functions & this

// this in nested objects

// Losing this (e.g., assigning a method to a variable)