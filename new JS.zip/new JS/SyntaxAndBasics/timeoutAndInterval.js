// setTimeout() - Executes after a delay - Once
// setInterval() - Executes repeatedly at intervals - Repeats

// clearTimeout() - Cancels a timeout
// clearInterval() - Cancels an interval

// setTimeout() 
console.log("Start");
setTimeout(() => {
    console.log("Timeout executed after 3 seconds");
}, 3000); // 2000 milliseconds = 2 seconds
console.log("End");

// setInterval()
let var_name= setInterval(() => {
    console.log("This runs every 2 seconds!");
}, 2000); //  Runs every 2 seconds

// clearInterval()
setTimeout(() => {
    clearInterval(var_name); // Stops the interval after 10 seconds
    console.log("Interval cleared after 10 seconds");
}, 10000); 

console.log("This will run immediately!");