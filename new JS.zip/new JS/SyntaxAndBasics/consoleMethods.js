// Using console.log(), console.error(), console.table(), etc.
// console.log()	Logs general messages to the console
// console.warn()	Displays a warning message
// console.error()	Displays an error message
// console.info()	Logs informational messages
// console.debug()	Logs debug messages (shown only in debug mode)
// console.assert()	Logs a message if the given condition is false
// console.time()	Starts a timer with a label
// console.timeLog()	Logs the elapsed time since console.time() was called
// console.timeEnd()	Stops the timer and logs the total time
// console.count()	Logs the number of times it has been called with a given label
// console.trace()	Displays the call stack leading to the current code
// console.group()	Starts a new collapsible console message group
// console.groupEnd()	Ends the most recently started message group
// console.table()	Logs tabular data (arrays/objects) as a formatted table
// console.clear()	Clears the console (was commented out in your code)


console.log("Hello, World!");
let x = 10;
console.log("The value of x is:", x);

console.warn("This is a warning!");

console.error("This is an error!");

console.info("This is an info message!");

console.debug("This is a debug message!");  // This will only show if the console is in debug mode

console.assert(x > 5, "x is not greater than 5!");  // will not throw an error
console.assert(x < 5, "x is greater than 5!");  // will throw an error

console.time("Timer"); // Start a timer
console.timeLog("Timer"); // Log the time elapsed since the timer started
// console.timeEnd("Timer"); // End the timer and log the time elapsed

console.count("Count"); // Count the number of times this line has been executed    
for (let i = 0; i < 2; i++) {
    console.count("Count"); // Count the number of times this line has been executed
}

console.trace("Trace message");
function calculateSum(a, b) {
    console.trace("calculateSum called with arguments:", a, "+", b, "=", a + b); // Trace message
    return a + b;
}
calculateSum(5, 10);

console.timeLog("Timer")

console.group("Group"); // Start a group of messages
console.log("Message 1");
console.group("Nested Group");
console.log("Nested Message 1");
console.groupEnd(); // Ends "Nested Group"
console.log("Message 3");
console.groupEnd(); // Ends "Group 1"
console.log("Outside Group");

console.table([{ name: "John", age: 30 }, { name: "Jane", age: 25 }]); // Log a table of data
console.table(["apple", "banana", "cherry"]); // Log a table of data

// console.clear(); // This will clear the console
