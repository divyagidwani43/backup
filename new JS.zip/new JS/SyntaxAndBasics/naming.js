// ✅ camelCase for variables
let userName = "Divya";
let userAge = 25;
let isLoggedIn = true;

// ✅ camelCase for functions
function getUserName() {
    return userName;
}

function isUserAdult(age) {
    return age >= 18;
}

// ✅ PascalCase for classes and constructor functions
class UserProfile {
    constructor(name, age) {
        this.name = name;
        this.age = age;
    }
}

function ProductItem(name, price) {
    this.name = name;
    this.price = price;
}

// ✅ UPPER_SNAKE_CASE for constants
const MAX_ATTEMPTS = 3;
const API_URL = "https://api.example.com";

// ❌ Avoid reserved keywords
// let class = "Math";     // ❌ SyntaxError
// let return = "value";   // ❌ SyntaxError

// ✅ Numbers can be in the name but not at the start
let user1 = "Alice";    // ✅
let user2 = "Bob";      // ✅
// let 1user = "Error";  // ❌ Invalid variable name
