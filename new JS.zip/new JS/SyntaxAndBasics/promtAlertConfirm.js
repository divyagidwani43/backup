// alert() - Displays a simple message - undefined
// prompt() - Asks for user input - string (or null if canceled)
// confirm() - Asks for a Yes/No confirmation	- true (OK) or false (Cancel)

alert("Hello, World!"); 


let userName = prompt("What is your name?"); 
alert("Hello, " + userName); 
let age = prompt("Enter your age:", "18"); // with a default value of "18"
console.log("User's age:", age);


let isConfirmed = confirm("Do you agree to the terms?");
console.log(isConfirmed); // ✅ true (OK) or false (Cancel)



if (username) {
    let agree = confirm(`Hello ${username}, do you accept the terms?`);
    if (agree) {
        alert("Welcome, " + username + "!");
    } else {
        alert("You need to accept the terms to proceed.");
    }
} else {
    alert("You didn't enter a name.");
}


document.write("<p>Hello, World!</p>");
