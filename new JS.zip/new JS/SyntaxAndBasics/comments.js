// Single-line and multi-line comments

/*
    This is a multi-line comment.
    It spans multiple lines.
*/