let age = 20;
if (age >= 18) {
  console.log("You're an adult");
}else{
    console.log("you're minor")
}


let score = 85;
if (score >= 90) {
  console.log("Grade: A");
} else if (score >= 75) {
  console.log("Grade: B");
} else {
  console.log("Grade: C or below");
}

// 0 - falsy
if (0) {
    console.log("Won't run");
  } else {
    console.log("Falsy value"); // ✅ This runs
  }
  
  