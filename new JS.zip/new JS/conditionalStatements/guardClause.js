function getGrade(score) {
    if (score < 0 || score > 100) { 
        console.log("Invalid Score"); 
        return;  // ✅ Exits early if input is out of range
    }
    switch (true) {
        case score >= 90:
            console.log("A");
            break;
        case score >= 80:
            console.log("B");
            break;
        case score >= 70:
            console.log("C");
            break;
        case score >= 60:
            console.log("D");
            break;
        default:
            console.log("F");
    }
}


// Without Guard Clause (Nested Code)
function getGrade(score) {
    if (score >= 0 && score <= 100) {
        switch (true) {
            case score >= 90:
                console.log("A");
                break;
            case score >= 80:
                console.log("B");
                break;
            case score >= 70:
                console.log("C");
                break;
            case score >= 60:
                console.log("D");
                break;
            default:
                console.log("F");
        }
    } else {
        console.log("Invalid Score");
    }
}

// ❌ The function has **extra nesting** inside `if (score >= 0 && score <= 100)`
