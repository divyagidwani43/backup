function trafficLight(color){
    switch(color){
        case "red":
            console.log("stop")
            break
        case "yellow":
            console.log("slow down")
            break
        case "green":
            console.log("go")
            break
        default:
            console.log("invalid")   
    }
}
trafficLight("red");    // ✅ "Stop"
trafficLight("green");  // ✅ "Go"
trafficLight("blue");   // ✅ "Invalid color"


// function getDaysInMonth(month){
//     switch(month){
//         case "January"|| "March"|| "May"|| "July"|| "August"|| "October"|| "December":
//             console.log("31 days")
//         case "April"|| "June"|| "September"|| "November":
//             console.log("30 days")
//         case "February":
//             console.log("28")
//         default:
//             console.log("invalid")
//     }   
// }
// getDaysInMonth("February");  // ✅ "28 or 29 days"
// getDaysInMonth("June");      // ✅ "30 days"
// getDaysInMonth("October");   // ✅ "31 days"
// getDaysInMonth("Hello");     // ✅ "Invalid month"

function getDaysInMonth(month) {
    switch (month) {
        case "January":
        case "March":
        case "May":
        case "July":
        case "August":
        case "October":
        case "December":
            console.log("31 days");
            break;  // ✅ Prevents fall-through
        
        case "April":
        case "June":
        case "September":
        case "November":
            console.log("30 days");
            break;
        
        case "February":
            console.log("28 or 29 days");
            break;
        
        default:
            console.log("Invalid month");
    }
}
getDaysInMonth("February");  // "28 or 29 days"
getDaysInMonth("June");      // "30 days"
getDaysInMonth("October");   // "31 days"
getDaysInMonth("Hello");     // "Invalid month"


function getGrade(score) {
    switch (true) {
        case (score >= 90 && score <= 100):
            console.log("A");
            break;
        case (score >= 80 && score < 90):
            console.log("B");
            break;
        case (score >= 70 && score < 80):
            console.log("C");
            break;
        case (score >= 60 && score < 70):
            console.log("D");
            break;
        case (score >= 0 && score < 60):
            console.log("F");
            break;
        default:
            console.log("Invalid Score");
    }
}
getGrade(95);  // ✅ "A"
getGrade(85);  // ✅ "B"
getGrade(75);  // ✅ "C"
getGrade(65);  // ✅ "D"
getGrade(50);  // ✅ "F"
getGrade(-5);  // ✅ "Invalid Score"
getGrade(110); // ✅ "Invalid Score"
