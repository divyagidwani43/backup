// condition1 && condition2
// returns first falsy value
// condition1 = true then condition2 returned
// condition1 = false then condition1 returned
true && false; // false
false && true; // false


// condition1 || condition2
// returns first truthy value
//  1 = true then condition1 returned
//  1= false then condition2 returned
true || "hi"; // true
false || true; // true
0 || false; // false

let inputName= prompt("Enter your name:");
let name = inputName || "Guest"; // use "Guest" if inputName is falsy
