/*
0
false
""
Nan
Undefined
null
*/