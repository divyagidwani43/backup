// Explicit type conversion using Number(), String()
String(123);       // "123"
Number("45");      // 45
Boolean(0);        // false
