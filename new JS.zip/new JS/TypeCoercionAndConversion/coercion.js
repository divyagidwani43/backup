// Dynamic Typing
let data = 10;       // number
data = "hello";      // now a string
data = false;        // now a boolean
// JavaScript allows changing types — no error

// Implicit Type Coercion (automatic conversion)
console.log("5" + 2);      // "52" → 2 is coerced to string
console.log("5" - 2);      // 3   → "5" is coerced to number


// Loose vs Strict Comparison
console.log("5" == 5);     // true → coerces before comparing
console.log("5" === 5);    // false → checks value and type
// Prefer === to avoid unexpected coercion

// Weird Coercion Cases
console.log([] + []);          // "" → both arrays become empty strings
console.log([] + {});          // "[object Object]"
console.log({} + []);          // 0 → treated as empty block + array

// 🔧 Explicit Coercion (you control the conversion)
console.log(Number("123"));     // 123 → string to number
console.log(String(100));       // "100" → number to string
console.log(Boolean(0));        // false → 0 is falsy
console.log(Boolean("hello"));  // true → non-empty string is truthy
