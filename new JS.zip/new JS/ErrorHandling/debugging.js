// Using try-catch for error handling
