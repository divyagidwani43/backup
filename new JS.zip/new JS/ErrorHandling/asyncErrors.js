// Handling errors in asynchronous code
