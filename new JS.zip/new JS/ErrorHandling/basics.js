// Using try-catch for error handling
/*
tryCatch.js – Using try...catch to handle errors

finally.js – The finally block and when to use it

customErrors.js – Creating and throwing custom errors using Error class

asyncErrors.js – Handling errors in asynchronous code (async/await, Promises)

onerror.js – Global error handling with window.onerror

eventError.js – Handling errors in event listeners

debugging.js – Debugging techniques using console.error, breakpoints, and stack traces

validationErrors.js – Handling user input validation errors

logging.js – Logging errors to an external service (e.g., Sentry, custom API)
*/