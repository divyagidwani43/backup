// Creating and throwing custom errors
