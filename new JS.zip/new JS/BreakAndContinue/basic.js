// Explain break and continue statements in loops
