// Practical examples of break and continue
