// Handling errors in async functions
