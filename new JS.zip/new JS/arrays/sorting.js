// sorting arrays (sort, reverse, localeCompare)
let fruits = ["banana", "apple", "cherry"];
fruits.sort();
console.log(fruits);


let numbers = [10, 2, 5, 1];
numbers.sort(); 
console.log(numbers);// ❌ [1, 10, 2, 5] (Incorrect sorting because it's sorted as strings)
numbers.sort((a, b) => a - b);
console.log(numbers);// ✅ [1, 2, 5, 10] (Correct numerical sorting)


let letters = ["a", "b", "c", "d"];
letters.reverse();
console.log(letters);


