// Common array methods (push, pop, shift, unshift, etc.)
let arr = [1, 2, 3];

arr.push(4); // [1, 2, 3, 4]
arr.pop();   // [1, 2, 3]

arr.unshift(0); // [0, 1, 2, 3]
arr.shift();    // [1, 2, 3]


// array.splice(startIndex, deleteCount, item1, item2, ...);
// startIndex	The position where changes begin
// deleteCount	Number of elements to remove
// item1, item2, ...	Elements to insert at startIndex (optional)
arr.splice(1, 1, "New", "here"); // [1, 'New', 'here', 3]
console.log(arr);
// adding using splice
arr.splice(1, 0, "New"); // [1, "New", "New", "here" , 3] 
console.log(arr); 
// removing using splice
arr.splice(1, 2); // [1, 3] (removes "New" and "here")
console.log(arr); 
// removing all
arr.splice(0); // [] (removes all elements)
console.log(arr); 


// The .slice() method extracts a section of an array without modifying the original array. 
// It returns a new array.
// array.slice(startIndex, endIndex);
let numbers = [10, 20, 30, 40, 50];

let sliced = numbers.slice(1, 4); // Extract from index 1 to 3 (4 is exclusive)
console.log(sliced); // [20, 30, 40]
console.log(numbers); // [10, 20, 30, 40, 50] (Original array unchanged)
// negative index
let slicedNegative = numbers.slice(-3); // Extract last 3 elements
console.log(slicedNegative); // [30, 40, 50]
// entire array
let slicedAll = numbers.slice(); // Copy entire array
console.log(slicedAll); // [10, 20, 30, 40, 50]
