// Feature	                Rest (...)	                              Spread (...)
// Purpose	         Collects multiple values into an array     Expands an array into individual elements
// Where Used	     Function parameters & destructuring        Array cloning, merging, passing arguments
// Works On	         Multiple values → One array	            One array  Multiple values
// Example	         function sum(...nums) {}                   let newArr = [...oldArr]


// Rest operator in array destructuring
let values = [1, 2, 3, 4, 5];
let [x, y, ...remaining] = values;

console.log(x);  // 1
console.log(y);  // 2
console.log(remaining);  // [3, 4, 5]

// Rest operator in function parameters
function total(...nums) {
    console.log(nums);
}
console.log(total(10, 20, 30, 40));  // [10, 20, 30, 40] undefined


// Spread operator in array expansion
let base = [1, 2];
let extendedArray = [...base, 3, 4, 5];

console.log(extendedArray);  // [1, 2, 3, 4, 5]

// Spread operator in merging arrays
let group1 = [1, 2, 3];
let group2 = [4, 5, 6];

let combined = [...group1, ...group2];

console.log(combined);  // [1, 2, 3, 4, 5, 6]

// Spread operator in function arguments
function add(p, q, r) {
    return p + q + r;
}

let numsArray = [10, 20, 30];

console.log(add(...numsArray));  // 60

// Spread operator in inserting elements into an array
let fruitsList = ["apple", "banana"];
let allFruits = ["orange", ...fruitsList, "grape"];

console.log(allFruits);  // ["orange", "apple", "banana", "grape"]

// Spread operator with strings
let text = "hello";
let chars = [...text];

console.log(chars);  // ["h", "e", "l", "l", "o"]
