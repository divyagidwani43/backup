let arr1 = [1, 2, 3];
let arr2 = [4, 5, 6];
let mergedArray = [...arr1, ...arr2];
console.log(mergedArray);  
// [1, 2, 3, 4, 5, 6]


let originalArr = ["apple", "banana"];
let clonedArr = [...originalArr];
console.log(clonedArr);  
// ["apple", "banana"]
