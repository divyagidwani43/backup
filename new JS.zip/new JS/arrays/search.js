// .indexOf() → Find First Occurrence
// Returns the index of the first matching element or -1 if not found.
let numbers = [10, 20, 30, 40, 20];

console.log(numbers.indexOf(20)); // 1
console.log(numbers.indexOf(50)); // -1 (Not found)

console.log(numbers.indexOf(20, 2)); // (Start searching from index 2)
console.log(numbers.indexOf(20, -2)); // (-2, which is the second last element)



// .lastIndexOf() → Find Last Occurrence
// Returns the index of the last matching element or -1 if not found.
console.log(numbers.lastIndexOf(20)); // 4
console.log(numbers.lastIndexOf(20, 3)); // 1 (Start searching from index 3)



// .includes() → Check if an Element Exists
// Returns true if the element is found, otherwise false.
console.log(numbers.includes(20)); // true



// .find() → Find First Matching Object
// Returns the first object that matches a condition, or undefined if not found.
let users = [
  { name: "John", age: 25 },
  { name: "Jane", age: 30 },
  { name: "Jack", age: 35 },
];
console.log(users.find((user) => user.age > 30)); // { name: 'Jack', age: 35 }
console.log(users.find((user) => user.age > 40)); // undefined (Not found)




// .findIndex() → Find Index of First Matching Object
// Returns the index of the first matching object or -1 if not found.
let index = users.findIndex(user => user.name === "Charlie");
console.log(index); // ✅ 2



// some() → Check if Any Element Matches
// Returns true if at least one element matches the condition, otherwise false.
let numbers11 = [1, 3, 5, 8];
let hasEven = numbers11.some(num => num % 2 === 0);
console.log(hasEven);
// some() Stops Early When It Finds a Match
let fruits = ["apple", "banana", "cherry"];
let hasBanana = fruits.some(fruit => fruit === "banana");
console.log(hasBanana);


// every() → Check if All Elements Match
// Returns true if all elements match the condition, otherwise false.
let numbers22 = [10, 20, 30, 40];
let allPositive = numbers22.every(num => num > 0);
console.log(allPositive);
