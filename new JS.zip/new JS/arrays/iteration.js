// Looping through arrays (for, forEach, map, etc.)
// all support break and continue statements not forEach
let numbers = [10, 20, 30, 40];
console.log("for loop")
for (let i = 0; i < numbers.length; i++) {
    console.log(numbers[i]);
}

console.log("while loop")
let i = 0;
while (i < numbers.length) {
    console.log(numbers[i]);
    i++;
}

console.log("for of loop")
for (let num of numbers) {
    console.log(num);
}


let fruits = ["Apple", "Banana", "Cherry"];
console.log("forEach loop")
fruits.forEach((fruit, index) => {
    console.log(`${index}: ${fruit}`);
});
// Cannot use break or continue inside .forEach().


