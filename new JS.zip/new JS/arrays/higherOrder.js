// Advanced methods like map, filter, reduce
// The .map() method is a higher-order function used to transform each element in an array and return a new modified array without changing the original one.
// array.map((element, index, array) => {});

let numbers = [1, 2, 3, 4, 5, 6];

let modified = numbers.map((num, index) => `Index ${index}: ${num * 2}`);
console.log(modified);

// array.filter((element, index, array) => {});
let evens = numbers.filter(num => num % 2 === 0);
console.log(evens);

// array.reduce((accumulator, currentValue, index, array) => {});
let sum = numbers.reduce((acc, num) => acc + num, 0); // 0 is the initial value
console.log(sum);

// .flatMap() and .flat() → Flatten Nested Arrays
// .flatMap() is a combination of map and flat, used to flatten the array by one level after mapping.
let arr = [1, [2, [3, ,[4, 5]]]];
console.log("flat",arr.flat(2)); // [1, 2, 3, [4, 5]] (flattens 2 levels and removes empty slot)

let deepArr = [1, [2, [3, [4, [5]]]]];
console.log(deepArr.flat(Infinity));  // [1, 2, 3, 4, 5] (completely flattened)

// array.flatMap((element, index, array) => { return modifiedElement;});
let numbers2 = [1, 2, 3 , 4];
let flatMapped = numbers2.flatMap(num => [num, num * 2]);
let mapped = numbers2.map(num => [num, num * 2]);
console.log(mapped);
console.log(flatMapped);


// concat() → Merge Arrays - newArray = array1.concat(array2, array3, ...);
let arr1 = [1, 2];
let arr2 = [3, 4];
let arr3 = [5, 6];
let merged = arr1.concat(arr2, arr3);
console.log(merged);

let arr11 = [1, 2];
let arr22 = [[3, 4]];
let merged1 = arr11.concat(arr22.flat());
console.log(merged1);


// join() → Convert Array to String -array.join(separator);
let arr33 = ["apple", "banana", "cherry"];
let result = arr33.join();
console.log(result);
console.log(arr33.join(""));  



