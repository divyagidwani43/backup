// Converting arrays to/from strings, objects, and sets

// Converting arrays to strings
let fruits = ["apple", "banana", "cherry"];
let str1 = fruits.join(); 
console.log(str1);

let str2 = fruits.join(" - "); 
console.log(str2);

// Converting strings to arrays
let str = "apple,banana,cherry";
let arr = str.split(",");
console.log(arr);
