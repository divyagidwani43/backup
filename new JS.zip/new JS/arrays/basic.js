// creating arrays
let fruits = ["Apple", "Banana", "Cherry"];
console.log(fruits); 

let numbers = new Array(10, 20, 30);
console.log(numbers); //  [10, 20, 30]

let arr = new Array(5); // Creates an empty array of length 5 (⚠️)
console.log(arr); //  [empty × 5]

// index
console.log(fruits[0]); // Apple

// modify
fruits[0] = "Orange";
console.log(fruits[0]); 

// length
console.log(fruits.length); // 3
console.log(fruits[fruits.length - 1]); // last element

// Immutability - means that the original data cannot be changed.
// Example: String is immutable 
const num = [1, 2, 3];
num.push(4,8); // Allowed (Modifies array)
num[1] = 99; // Allowed (Changes value)
console.log(num); // [1, 99, 3, 4]

// immutable concepts of array
// map, filter, reduce, slice, concat, spread operator dont modify the original array