// Array destructuring allows extracting values from an array into variables
let food = ["pizza", "burger", "pasta"];
let [item1, item2, item3] = food;
console.log(item1);  
console.log(item2);  
console.log(item3);  

// Skipping elements using commas
let shades = ["black", "white", "gray", "purple"];
let [shade1, , shade3] = shades;
console.log(shade1);  
console.log(shade3);  

// Providing default values if an array element is undefined
let digits = [15];
let [num1, num2 = 25, num3 = 35] = digits;
console.log(num1);  
console.log(num2);  
console.log(num3);  

// Swapping values without using a temporary variable
let m = 8, n = 12;
[m, n] = [n, m];
console.log(m);  
console.log(n);  

// Using the rest operator to collect remaining elements
let people = ["John", "Emma", "Sophia", "Liam"];
let [person1, person2, ...others] = people;
console.log(person1);  
console.log(person2);  
console.log(others);  

// Nested array destructuring
let coords = [5, [10, 15], 20];
let [p, [q, r], s] = coords;
console.log(p);  
console.log(q);  
console.log(r);  
console.log(s);  

// Destructuring values from a function return
function fetchData() {
    return [42, 84];
}
let [val1, val2] = fetchData();
console.log(val1);  
console.log(val2);  

// Destructuring with default values in a function parameter
function check(...args) {
    console.log(...args);
}
check(8, 7, 6, 5, 4); // Can take any number of arguments
// another way
function check(arr) {
    console.log(...arr);
}
check([8, 7, 6, 5, 4]); // Passing an array
