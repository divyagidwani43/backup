// +    Addition  
// -    Subtraction  
// *    Multiplication  
// /    Division  
// %    Modulus (remainder)  
// **   Exponentiation  
// ++   Increment  
// --   Decrement  

