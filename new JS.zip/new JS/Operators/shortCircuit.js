// ! NOT
// Flips truthiness

// || OR
// Returns first truthy

// && AND
// Returns first falsy or last truthy


// && returns the first falsy or last truthy
console.log(true && "Hello");     // "Hello"
console.log(false && "Hello");    // false

// || returns the first truthy
console.log(0 || "Guest");        // "Guest"
console.log("User" || "Guest");   // "User"

// You can use this to provide defaults:
let username = input || "Guest";