// ==     Equal (type-coerced)  
// ===    Equal (strict)  
// !=     Not equal  
// !==    Strict not equal  
