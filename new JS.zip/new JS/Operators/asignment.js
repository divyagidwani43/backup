// =     Assignment
// +=    Add and assign
// -=    Subtract and assign
// *=    Multiply and assign
// /=    Divide and assign
// %=    Modulus and assign
// **=   Exponentiate and assign  
