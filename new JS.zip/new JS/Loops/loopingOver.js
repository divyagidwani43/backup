// arrays
let fruits = ["apple", "banana", "cherry"];
for (let i = 0; i < fruits.length; i++) {
    console.log(fruits[i]);
}

fruits.forEach((fruit, index) => console.log(index, fruit));

for (let fruit of fruits) {
    console.log(fruit);
}

// objects
let person = { name: "Alice", age: 25, city: "New York" };
for (let key in person) {
    console.log(key, person[key]);
}

for (let [key, value] of Object.entries(person)) {
    console.log(key, value);
}
