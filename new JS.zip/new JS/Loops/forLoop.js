// Explain for loop and its variations
// for (initialization; condition; update) {}
for (let i = 1; i <= 5; i++) {
    console.log(i);
}

for (let i = 1; i <= 5; i++) {
    if (i === 3) continue;  // Skip 3
    console.log(i);
}
// 1 2 4 5

for (let i = 1; i <= 5; i++) {
    if (i === 3) break;  // Stop at 3
    console.log(i);
}
// 1 2

for (let i = 1; i <= 3; i++) {
    for (let j = 1; j <= i; j++) {
        console.log(`${i}, ${j}`);
    }
}
