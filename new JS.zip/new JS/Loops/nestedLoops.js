// Explain while and do-while loops
