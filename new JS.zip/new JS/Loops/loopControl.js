// Explain while and do-while loops
// 1️⃣ break → Stops the loop immediately.
// 2️⃣ continue → Skips the current iteration and moves to the next.
// 3️⃣ return → Exits a function (inside a loop, it stops both the function and the loop).
function findEvenNumber() {
    for (let i = 1; i <= 5; i++) {
        if (i % 2 === 0) {
            console.log(`First even number found: ${i}`);
            break;  // Exits loop but continues function
        }
    }
    console.log("Loop exited but function continues.");
}
findEvenNumber();
// First even number found: 2
// Loop exited but function continues.


function findEvenNumber() {
    for (let i = 1; i <= 5; i++) {
        if (i % 2 !== 0) {
            continue;  // Skips odd numbers
        }
        console.log(`Even number found: ${i}`);
    }
    console.log("Loop completed.");
}
findEvenNumber();
// Even number found: 2
// Even number found: 4
// Loop completed.


function findEvenNumber() {
    for (let i = 1; i <= 5; i++) {
        if (i % 2 === 0) {
            console.log(`First even number found: ${i}`);
            return;  // Exits the function
        }
    }
    console.log("No even number found.");
}
findEvenNumber();
// First even number found: 2
