// Explain while and do-while loops
while (condition) {
    // Code to execute
}
let count = 1;
while (count <= 5) {
    console.log(count);
    count++;  // Increment to avoid infinite loop
}

let num = 1;
while (num <= 10) {
    if (num === 5) {
        console.log("Stopping at 5");
        break;  // Stops the loop
    }
    console.log(num);
    num++;
}
// 1 2 3 4 Stopping at 5

let num2 = 0;
while (num2 < 5) {
    num2++;
    if (num2 === 3) {
        continue;  // Skips 3 and moves to the next iteration
    }
    console.log(num2);
}
// 1 2 4 5 
