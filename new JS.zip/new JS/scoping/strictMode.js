"use strict";

let x = 10; // ✅ Works fine

x = 10; // ❌ ReferenceError: x is not defined
//Prevents Implicit Global Variables
