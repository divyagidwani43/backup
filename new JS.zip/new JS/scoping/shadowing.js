let x = 10; 
function example() {
    let x = 20; // Shadows global `x`
    console.log(x); // 20 
}
example();
console.log(x); // 10 (global x remains unchanged)


let name = "Alice";
function greet() {
    let name = "Bob"; // Shadows outer `name`
    console.log("Hello, " + name);
}
greet(); // "Hello, Bob"
console.log(name); // "Alice" (global `name` remains unchanged)
