// let and const are block-scoped and function-scoped
// var is function-scoped, not block-scoped

function example() {
    var a = 10;  // Scoped to this function
    let b = 20;  // Scoped to this function
    const c = 30; // Scoped to this function
}
// console.log(a); // ❌ ReferenceError: a is not defined
// console.log(b); // ❌ ReferenceError: b is not defined
// console.log(c); // ❌ ReferenceError: c is not defined


// function comes with its own scope, so variables declared inside a function are not accessible outside of it.
function outer() {
    let outerVar = "I'm outside!";

    function inner() {
        let innerVar = "I'm inside!";
        console.log(outerVar); // ✅ Accessible
        console.log(innerVar); // ✅ Accessible
    }

    inner();
    // console.log(innerVar); // ❌ ReferenceError: innerVar is not defined
}

outer();
