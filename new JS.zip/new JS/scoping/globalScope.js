let globalVar = "I am global"; 
function testFunction() {
    console.log(globalVar); // ✅ 
}
testFunction();
console.log(globalVar); // ✅ 
 


// In browsers, global variables become properties of the window object or globalThis 
var globalVar2 = "I am global"; 
console.log(window.globalVar2); // ✅ only when declared using var
console.log(globalThis.globalVar2); // ✅ 



function createGlobal() {
    accidentalGlobal = "Oops!"; // No declaration keyword
}
createGlobal();
console.log(accidentalGlobal); // Accessible globally 
// The accidentalGlobal in your code behaves like a var declaration in the global scope.
// It is not block-scoped ,is hoisted and can be reassigned.
// Assigning a variable without let, const, or var makes it an implicit global, 
