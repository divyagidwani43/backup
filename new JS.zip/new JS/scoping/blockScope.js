// Block scope means that variables declared inside a block { ... } are only accessible within that block.
// A block can be an if, for, while, or {} alone
{

    let a = 10;
    const b = 20;
    var c = 30; // var not block-scoped
    console.log(a); // ✅ 

}
console.log(a); // ❌ 
console.log(b); // ❌ 
console.log(c); // ✅ var



// for Block Scope
for (let i = 0; i < 3; i++) {
    console.log(i); 
}
console.log(i); // ❌ 

// But if you use var
for (var j = 0; j < 3; j++) {
    console.log(j); 
}
console.log(j); // ✅



// nested blocks
{
    let outer = "I'm outer!";
    
    {
        let inner = "I'm inner!";
        console.log(outer); // ✅ 
        console.log(inner); // ✅ 
    }

    console.log(outer); // ✅ 
    console.log(inner); // ❌ 
}


