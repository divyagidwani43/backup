/*
false
0
-0
""     
null
undefined
NaN    
*/

