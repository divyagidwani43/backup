// Understanding variable and function hoisting

// LET
console.log(a);  //error
let a = 7;
console.log(a); // dont execute due to error
// let is hoisted but remains in the Temporal Dead Zone (TDZ) from the start of the block until its initialization.
// Accessing a before its declaration causes an error.

let a1;
console.log(a1); // undefined
a1 = 7;
console.log(a1); // 7


// VAR
console.log(a2); //  undefined
var a2 = 7;
console.log(a2); //  7
// var is hoisted to the top of its scope and is initialized with undefined.
// This means the variable exists before its declaration

/*
        hoisted      initial value           TDZ
var	    ✅ Yes	 undefined	              ❌ No
let	    ✅ Yes	❌ ReferenceError (TDZ)	✅ Yes
const	✅ Yes	❌ ReferenceError (TDZ)	✅ Yes

*/

sayHello();  // ❌ TypeError: sayHello is not a function
var sayHello = function() {
    console.log("Hello!");
};


greet(); // ❌ ReferenceError: Cannot access 'greet' before initialization
const greet = () => console.log("Hello!");
