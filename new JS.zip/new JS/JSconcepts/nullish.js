let result = value1 ?? value2;
// If value1 is null or undefined, value2 is returned.

let count = 0;
console.log(count || 100);  // ❌ 100 (Because `0` is falsy)
console.log(count ?? 100);  // ✅ 0   (Because `0` is not null/undefined)
