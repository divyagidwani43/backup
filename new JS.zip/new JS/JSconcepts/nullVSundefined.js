// Undefined → when a variable is declared but not assigned
console.log(x);
let x = 8;  // Uncaught ReferenceError: x is not defined

// Null → when a developer assigns empty value on purpose
let x2 = null;
console.log(x2); // null - no error

console.log(null == undefined);  // true (loose equality)
console.log(null === undefined); // false (strict equality)
