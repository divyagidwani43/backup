"use strict";  // Enabling strict mode

// 1️⃣ Using Undeclared Variables
// x = 10;  // ❌ ReferenceError: x is not defined

// 2️⃣ Assigning to Read-Only Global Properties
// NaN = 5;  // ❌ TypeError: Cannot assign to read only property 'NaN'

// 3️⃣ Deleting Variables and Functions
let a = 10;
// delete a;  // ❌ SyntaxError: Delete of an unqualified identifier

// 4️⃣ Duplicate Parameter Names
// function sum(a, a) {  // ❌ SyntaxError: Duplicate parameter name not allowed
//     return a + a;
// }

// 5️⃣ Octal Number Literals (0 prefix)
// let num = 010;  // ❌ SyntaxError: Octal literals are not allowed
let validOctal = 0o10;  // ✅ Correct way to write octal

// 6️⃣ Implicit `this` in Functions Defaults to `undefined`
function checkThis() {
    console.log(this);  // ❌ undefined instead of `window`
}
checkThis();

// 7️⃣ `with` Statement is Forbidden
// with (Math) {  // ❌ SyntaxError: Strict mode code may not include a with statement
//     console.log(PI);
// }

// 8️⃣ Assigning to a Function Parameter Object (`arguments`)
function modifyArguments(x) {
    // arguments[0] = 10;  // ❌ Doesn't update x in strict mode
    console.log(x);  
}
modifyArguments(5);

// 9️⃣ Deleting Function Names
function greet() {}
// delete greet;  // ❌ SyntaxError: Cannot delete function declaration

// 🔟 Defining Properties on Objects with `writable: false`
let obj = Object.defineProperty({}, "prop", { value: 10, writable: false });
// obj.prop = 20;  // ❌ TypeError: Cannot assign to read-only property 'prop'

console.log("Strict mode rules demonstrated!");
