// Use === for strict comparisons to avoid unexpected type coercion.
// Use == only when you explicitly need type conversion.

console.log(5 == "5");  // ✅ true  (type coercion: "5" → 5)
console.log(5 === "5"); // ❌ false (different types)

