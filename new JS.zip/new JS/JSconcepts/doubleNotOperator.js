// The double NOT (!!) operator converts any value into its boolean equivalent.

// 🔹 How It Works?
// The first ! negates the value, converting it to true or false.
// The second ! negates it again, effectively forcing it into a boolean (true or false).

console.log(!!1);         // ✅ true (1 is truthy)
console.log(!!0);         // ✅ false (0 is falsy)

let userInput = "Hello";
if (!!userInput) {
    console.log("User entered a value"); // ✅ Executes
}
