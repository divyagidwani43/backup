// Handling errors in promises
