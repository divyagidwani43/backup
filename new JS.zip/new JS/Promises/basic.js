// Explain Promises and how they work
function getVar(isTrue) {
    return (
        promise1 = new Promise(function (resolve, reject) {
            if (isTrue) {
                resolve("condition true")
            } else {
                reject("not")
            }
        })
    )
}
let promiseStoredHere = getVar(true)
promiseStoredHere
    .then(function (message) {
        console.log(message, "anything")
    })
    .catch(function (message) {
        console.log(message, "error mess")
    })


let promiseStoredHereAgain = getVar(false)
promiseStoredHereAgain
    .then(function (message) {
        console.log(message, "anything")
    })
    .catch(function (message) {
        console.log(message, "error mess")
    })