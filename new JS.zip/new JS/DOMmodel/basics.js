console.dir(document);
console.log(document)

console.log(document.getElementById("title"));
console.log(document.getElementsByClassName("class"))
console.log(document.getElementsByClassName("class")[2]) // Access the second element with the class "class"
console.log(document.getElementsByTagName("div"))

console.log("info", document.querySelector(".info"))
console.log("info all", document.querySelectorAll(".info")[1])


setTimeout(() => {
    console.log(document.getElementById("innerHTML").innerHTML = "<h3>dijdiej</h3>")
    console.log(document.getElementById("innertext").innerText = "<h3>dijdiej</h3>")
    document.getElementById("textContent").textContent = "<h1>hdiubuiebr</h1>"
    document.getElementById("outerHTML").outerHTML = "<h1>hdiubuiebr</h1>"
    document.getElementById("logo").setAttribute("src", "dom.png")
    document.getElementById("btn").removeAttribute("disabled")

}, 2000);