// Feature	                                var	                                  let	                    const
// Scope	                          Function-scoped	                    Block-scoped ({})	      Block-scoped ({})
// Re-declarable	                      ✅ Yes	                               ❌ No	                    ❌ No
// Re-assignable	                      ✅ Yes	                               ✅ Yes	                ❌ No
// Hoisted	                    ✅ Yes (initialized as undefined)	 ✅ Yes (but TDZ applies)	    ✅ Yes (TDZ applies)
// Must be initialized	                  ❌ No	                               ❌ No	                    ✅ Yes

