// 1. Must initialize on declaration
// 2. Cannot reassign
// 3. Mutation is allowed, reassignment is not
// 4. Block scope, function scope
// 5. Temporal Dead Zone (TDZ)

const pi = 3.14;
// const version; // ❌ Error

// 2. Cannot reassign
const maxUsers = 100;
// maxUsers = 150; // ❌ TypeError

// 3. Mutation is allowed, reassignment is not
const profile = { name: "Divya" };
profile.name = "Divs";

const marks = [80, 85];
marks.push(90);

// profile = {}; // ❌
// marks = [];   // ❌

// 4. Block scope
{
    const message = "Hello";
    console.log(message);
}
// console.log(message); // ❌

// 5. Temporal Dead Zone (TDZ)
// console.log(city); // ❌
const city = "Paris";
