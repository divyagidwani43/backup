var username = "Divya";
console.log(username);


var pet = "dog";
var pet = "cat"; // ✅ Allowed
console.log(pet); // "cat"

// Function Scope (not block-scoped)
function demo() {
    var color = "blue";

    if (true) {
        var color = "red";
        console.log("Inside if:", color);
    }

    console.log("Outside if:", color); // red
}
demo();
// console.log(color) // ❌



// 4. Hoisting (initialized as undefined)
console.log(tool); // undefined
var tool = "Hammer";



// 5. Loop issue with var (no block scope)
for (var i = 0; i < 3; i++) {
    setTimeout(() => console.log(i), 100); // 3, 3, 3
}
console.log(i) // 3


var animal = "cat";
let animal = "dog";
console.log(animal); // ❌ SyntaxError: Identifier 'animal' has already been declared