let username;          // Declared (undefined)
username = "Alice";    // Initialized later


let userAge = 25;
userAge = 26;          // ✅ Reassigned
// let userAge = 30;   // ❌ Cannot re-declare in same scope
// but
{
    let userAge = 30;
    console.log(userAge) // works
}


// Block Scope
if (true) {
    let alertMsg = "Warning!";
    console.log(alertMsg); // ✅ 
}
// console.log(alertMsg); // ❌ ReferenceError: outside block


// Function Scope
function showStatus() {
    let status = "Online";
    console.log(status); // ✅ 
}
showStatus();
// console.log(status); // ❌ ReferenceError


// Temporal Dead Zone (TDZ)
console.log(product); // ❌ ReferenceError (TDZ)
let product = "Laptop";
