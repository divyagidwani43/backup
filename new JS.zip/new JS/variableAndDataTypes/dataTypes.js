// primitive
// type	            Example	                     Description

// String	     "hello", 'abc'	                 Text data
// Number	     42, 3.14, -1	                 Integers + floats (same type!)
// Boolean	     true, false	                 Logic values
// Undefined	 let x; → x === undefined	     Variable declared but not assigned
// Null	         let x = null;	                 Intentional empty value
// Symbol	     Symbol("id")	                 Unique identifier (rare use case)
// BigInt	     12345678901234567890n	         For huge integers beyond safe limit

typeof 42         // "number"
typeof "hello"    // "string"


// Object	  { name: "Divya", age: 21 }	Key-value pairs
// Array	  [1, 2, 3]	                    Ordered list (technically objects)
// Function	  function() {}	                Callable object
// Date, RegExp, Map, Set	                Built-in objects
