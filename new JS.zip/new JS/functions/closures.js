function outer() {
    let count = 0; // Variable inside outer function

    return function inner() {
        count++; // Inner function still has access to count
        console.log(count);
    };
}

const counter = outer(); // outer() runs, but inner() is saved in counter
counter(); // 1
counter(); // 2
counter(); // 3



function createCounter() {
    let count = 0; // Private variable

    return {
        increment: function () {
            count++;
            console.log(count);
        },
        decrement: function () {
            count--;
            console.log(count);
        },
        getCount: function () {
            return count;
        }
    };
}

const myCounter = createCounter();
myCounter.increment(); // 1
myCounter.increment(); // 2
console.log(myCounter.getCount()); // 2

console.log(myCounter.count); // ❌ Undefined (count is private)
