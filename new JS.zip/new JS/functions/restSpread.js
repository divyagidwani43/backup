// Using .bind(), .call(), and .apply()
function greet(message, ...names) {
    console.log(message, names);
}

greet("Hello", "Alice", "Bob", "Charlie"); 
// ✅ "Hello" ["Alice", "Bob", "Charlie"]
