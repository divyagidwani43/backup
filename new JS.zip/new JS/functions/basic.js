// Declaring and calling functions using the function keyword
function sum(a,b){
    return a+b
}
console.log(sum(4,5))


// Rest Parameters (function sum(...nums) {})
function sum(...nums) {
    console.log(nums , " when spread ", ...nums)
}

console.log(sum(1, 2, 3, 4, 5)); // Output: 15
console.log(sum(10, 20));        // Output: 30
console.log(sum());              // Output: 0

// Hoisting (function declarations are hoisted)
// Function declarations are fully hoisted, meaning you can call them before they are defined.
sayHello(); //  Works!
function sayHello() {
    console.log("Hello!");
}

// arguments display all arguments
function sum() {
    console.log(arguments); // ✅ Works
}
sum(1, 2, 3); // Output: [1, 2, 3]
