// Understanding generator functions
