// Making functions asynchronous with async/await
// "use strict";

function showThis() {
    console.log(this);
}
// showThis(); // ❌ undefined (because of strict mode)
showThis(); // not in strict mode, this would be window



const person = {
    name: "Alice",
    greet: function() {
        // Since greet() is called on person, this refers to person.
        console.log(`Hello, my name is ${this.name}`);
    }
};




const person2 = {
    name: "Bob",
    greet: function() {
        const inner = () => {
            //inner() is an arrow function, so it inherits this from greet(), which is inside person.
            console.log(this.name);
        };
        inner();
    }
};



const person3 = {
    name: "Charlie",
    greet: function() {
        function inner() {
            // inner() is a regular function, so this becomes undefined (strict mode) or refers to the global object.
            console.log(this.name);
        }
        inner();
    }
};

