// How 'this' works in different function contexts
const greet = function() {
    console.log("Hello!");
};
greet(); 

// Function Expression Inside an Object (Method)
const person = {
    name: "Alice",
    greet: function() {
        console.log(`Hello, I am ${this.name}`);
    }
};
person.greet(); 

// Function Expressions are NOT Hoisted
// This prevents accidental usage before definition.
//  Helps in defining methods inside objects
// Function expressions are often used for closures and self-executing functions.

// this
// depends where it is called takes up the parent object or function