// Recursive functions and their use cases
// IIFE (Immediately Invoked Function Expression) is a function that runs immediately after it is defined.
(function() {
    console.log("IIFE executed!");
})(); 

// Arrow Function IIFE
(() => {
    console.log("Arrow function IIFE!");
})(); 


// IIFE with Parameters
(function(name) {
    console.log(`Hello, ${name}!`);
})("Alice"); 

// IIFE with Return Value
const result = (function() {
    return "Returned from IIFE";
})();
console.log(result); 

