// Using arrow functions and their differences from regular functions
let sum = (a,b) =>{
    return a+b
}
console.log(sum(4,5))
// do not have their own this They inherit this from the surrounding scope (useful in callbacks).
// Arrow functions are NOT hoisted




const person = {
    name: "Charlie",
    greet: function() {
        const inner = () => {
            console.log(`Hello, I am ${this.name}`);
        };
        inner(); // ✅ "Hello, I am Charlie"
    },
    greetReg: function() {
        function inner() {
            console.log(`Hello, I am ${this.name}`);
        }
        inner(); // ❌ `this` is undefined
    }
};

person.greet();
person.greetReg();




// ✔ Arrow function does NOT have arguments
const sum1 = () => console.log(arguments); // ❌ ERROR: arguments is not defined
