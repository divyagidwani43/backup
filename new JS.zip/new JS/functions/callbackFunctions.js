// Immediately Invoked Function Expressions (IIFE)
function greet(name, functionInput) {
    console.log(`Hello, ${name}`);
    functionInput();
}
function sayGoodbye() {
    console.log("Goodbye!");
}

greet("Alice", sayGoodbye); 

