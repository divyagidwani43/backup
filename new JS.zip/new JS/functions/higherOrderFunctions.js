function operate(a, b, operation) {
    return operation(a, b); 
}
function add(x, y) {
    return x + y;
}
console.log(operate(5, 3, add)); // ✅ 8


function multiplier(factor) {
    return function(number) {
        return number * factor;
    };
}
const double = multiplier(2);
console.log(double(5)); // ✅ 10

// .map(), .filter(), and .reduce() are higher-order functions!

