// Using rest and spread operators in functions
