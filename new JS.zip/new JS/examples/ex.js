function getDaysInMonth(month) {
    const monthDays = {
        "January": 31, "March": 31, "May": 31, "July": 31,
        "August": 31, "October": 31, "December": 31,
        "April": 30, "June": 30, "September": 30, "November": 30,
        "February": "28 or 29"
    };

    console.log(monthDays[month] || "Invalid month");
}

// ✅ Testing
getDaysInMonth("February");  // "28 or 29"
getDaysInMonth("June");      // "30"
getDaysInMonth("October");   // "31"
getDaysInMonth("Hello");     // "Invalid month"
