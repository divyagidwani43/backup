let text = "JavaScript is an amazing programming language!";

console.log(text.indexOf("am")); 
console.log(text.lastIndexOf("a")); 
console.log(text.includes("programming")); 
console.log(text.startsWith("JavaScript")); 
console.log(text.endsWith("language!")); 