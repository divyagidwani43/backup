// Creating and manipulating strings
let str1 = "Hello";   // Double quotes
let str2 = 'World';   // Single quotes
let str3 = `Hi, ${str1}!`; // Template literals (Backticks)

let text = "JavaScript";
console.log(text.length);  // 10 (Number of characters)
console.log(text[0]);      // "J" (First character)
console.log(text[text.length - 1]); // "t" (Last character)


// .toUpperCase()      	    New string	Converts to uppercase
// .toLowerCase()      	    New string	Converts to lowercase
// .trim()      	        New string	Removes spaces from start & end
// .slice(start, end)       New string	Extracts part of a string
// .substring(start, end)   New string	Similar to slice() but no negative index
// .replace(old, new)       New string	Replaces first match
// .replaceAll(old, new)    New string	Replaces all matches (ES2021
// .split(separator)      	Array	    Splits into an array
// .indexOf(substring)      Number	    Finds position of substring
// .includes(substring)     true/false	Checks if substring exists
// .startsWith(prefix)      true/false	Checks start of string
// .endsWith(suffix)      	true/false	Checks end of string
// .repeat(n)      	        New string	Repeats the string n times
