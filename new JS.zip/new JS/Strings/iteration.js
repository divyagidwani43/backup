let str = "Hello";
for (let i = 0; i < str.length; i++) {
    console.log(str[i]);  // ✅ H, e, l, l, o
}

let str2 = "World";
for (let char of str2) {
    console.log(char);  // ✅ W, o, r, l, d
}

