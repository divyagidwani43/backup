
let str = "  JavaScript is fun!  ";

console.log(str.toUpperCase());             // "  JAVASCRIPT IS FUN!  "
console.log(str.toLowerCase());             // "  javascript is fun!  "
console.log(str.trim());                    // "JavaScript is fun!"
console.log(str.slice(0, 10));              // "JavaScript"
console.log(str.replace("fun", "awesome")); // "  JavaScript is awesome!  "
console.log(str.includes("fun"));           // true
console.log(str.startsWith("Java"));        // false (because of leading spaces)
console.log(str.trim().startsWith("Java")); // true
console.log(str.split(" "));                // ["", "", "JavaScript", "is", "fun!", "", ""]
console.log("Hello ".repeat(3));            // "Hello Hello Hello "
