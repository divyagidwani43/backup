// Explain spread operator and its use cases
