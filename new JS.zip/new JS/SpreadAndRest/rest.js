// Explain rest parameter and its use cases
